var rootDocment = 'https://3g.dongdonggj.com/mxapi.php';//你的域名  
function req(url,data,cb){  
  wx.showNavigationBarLoading()//设置在导航条上显示Loading加载状态
    wx.request({  
      url: rootDocment + url,
      data: data,
      method: 'GET',
      header: {'Content-Type': 'application/json'},  
      success: function(res){  
        wx.hideNavigationBarLoading()// 隐藏Loading加载状态
        return typeof cb == "function" && cb(res.data)  
      },  
      fail: function(){  
        return typeof cb == "function" && cb(false)  
      }  
    })  
}  
  
  
module.exports = {  
  req: req  
}  