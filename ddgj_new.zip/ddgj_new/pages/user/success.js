// pages/user/success.js
var app = getApp()
Page({
  data:{
    pic_path:app.pic_path,
    mx_dy:'none'
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
    app.util.request({
        url: 'entry//get_tj_brand_list',
        data: {
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            that.setData({list:res.data.data})
        }
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  go_order:function(){
    wx.redirectTo({
      url: 'new_order',
    })
  },
  go_fx:function(){
    wx.navigateTo({
      url: 'fx',
    })
  },
  show_ot:function(e){
    var list = e.currentTarget.dataset.id
    this.setData({mx_dy:'show',md_list:list})
  },
  close_ot:function(){
    this.setData({mx_dy:'none'})
  }
})