// pages/user/jyfs.js
var app = getApp()
Page({
  data:{
    info:[],
    mx_type:'',
    address:'',
    phone:'',
    id:''
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var id = options.id;
    var that = this
    app.func.req('',{'op':'get_jyfs','id':id,'cs_type':1},function(res){
        that.setData({info:res.info,id:id,phone:res.info.phone,mx_type:1})
    });
  },
  radioChange: function(e) {
    this.setData({mx_type:e.detail.value})
  },
  get_address:function(e){
    this.setData({address:e.detail.value})
  },
  get_phone:function(e){
    this.setData({phone:e.detail.value})
  },
  add_info:function(){
    var data = this.data
    // console.log('--id'+data.info.id+"--cs_id"+data.id+"--type"+data.mx_type+"--address"+data.address+'--phone'+data.phone)
    var id = data.info.id
    var cs_id = data.id
    var type1 = data.mx_type
    var address = data.address
    var phone = data.phone
    var mx_data = {'op':'add_jyfs','id':id,'cs_id':cs_id,'type':type1,'address':address,'phone':phone}
    app.func.req('',mx_data,function(res){
        wx.showToast({
          title: '确认成功',
          icon: 'success',
          duration: 2000
        })
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})