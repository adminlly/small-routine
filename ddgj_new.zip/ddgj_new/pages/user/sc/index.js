// pages/user/sc/index.js
var app = getApp()
var data = require('../../data/user.js')
Page({
  data:{
    /** 
        * 页面配置 
        */  
    winWidth: 0,  
    winHeight: 0,  
    // tab切换  
    currentTab: 0,  
    pic_path:app.pic_path,
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    /** 
     * 获取系统信息 
     */  
    var that = this
    wx.getSystemInfo( {  
      success: function( res ) {  
        that.setData( {  
          winWidth: res.windowWidth,  
          winHeight: res.windowHeight  
        });  
      }  
    });  
    app.util.getUserInfo(function (user) {
       //console.log(user)
       data.user_sc_list(user.memberInfo.id,function(res){
         that.setData({brand_sc_list:res.data.brand_sc_list,ybj_sc_list:res.data.ybj_sc_list})
       })
     });
  },
  /** 
     * 滑动切换tab 
     */  
  bindChange: function( e ) {  
    var that = this;  
    that.setData( { currentTab: e.detail.current });  
  
  },  
  /** 
   * 点击tab切换 
   */  
  swichNav: function( e ) {  
    var that = this;  
    if( this.data.currentTab === e.target.dataset.current ) {  
      return false;  
    } else {  
      that.setData( {  
        currentTab: e.target.dataset.current  
      })  
    }  
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})