var app = getApp()
var data = require('../data/user.js')
Page( {  
  data: {  
    /** 
        * 页面配置 
        */  
    winWidth: 0,  
    winHeight: 0,  
    // tab切换  
    currentTab: 0,  
    dfdj_order:[],
    ot_order:[],
    pic_path:app.pic_path,
    uid:'',
    openid:'',
    fee:0,
  },  
  onLoad: function(options) {  
    var that = this;  
    var currentTab = options.currentTab
    that.setData({currentTab:currentTab})
    /** 
     * 获取系统信息 
     */  
    wx.getSystemInfo( {  
      success: function( res ) {  
        that.setData( {  
          winWidth: res.windowWidth,  
          winHeight: res.windowHeight  
        });  
      }  
    });
    app.util.getUserInfo(function(userInfo){
        var user = userInfo.memberInfo
        that.setData({uid:user.id,openid:user.openid,phone:user.phone})
        if(user.name==''){
            app.register()
        }else{
          that.order_info(user.id)
            // data.get_new_xcx_order(user.id,function(res){
            //     that.setData({all_list:res.all_list,dfk_list:res.dfk_list,dpj_list:res.dpj_list})
            // })
        }
    })
  },
  order_info:function(uid){
      var that = this
      data.get_new_xcx_order(uid,function(res){
                that.setData({all_list:res.all_list,dfk_list:res.dfk_list,dpj_list:res.dpj_list})
            })
      // data.get_order(uid,status,function(res){
      //     if(status==0){
      //         that.setData({dfdj_order:res.data})
      //     }else if(status==1){
      //         that.setData({ot_order:res.data})
      //     }else{
      //         that.setData({pj_order:res.data})
      //     }
      // })
  },
  /**
   * 获取需要支付的金额
   */
  get_price:function(e){
    var id = e.currentTarget.id
    var price = e.detail.value
    var regNum=new RegExp('^[1-9]*[1-9][0-9]*$','g');
    var rst = regNum.exec(price)
    console.log(rst)
    if(rst === null){
       wx.showToast({
        title: '请输入大于0的数字',
        icon: 'success',
        duration: 2000
      })
    }else{
      this.setData({fee:price})
    }
   
  },
  /**
   * 退款申请
   */
  tk:function(e){
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '提示',
      content: '确认申请退款',
      success: function(res) {
        if (res.confirm) {
           app.util.request({
              url: 'entry//user_sq_tk',
              data: {
                  id:id,
                  m: 'qcp_ddgj',
              },
              cachetime: 0,
              success: function (res) {
                  if (res.data.code == 1) {
                      that.order_info(that.data.uid)
                      that.setData({currentTab:3})
                      wx.showToast({
                        title: '申请成功',
                        icon: 'success',
                        duration: 2000
                      })
                  } else {
                      
                  }
              }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  /**
   * 拨打电话
   */
  mx_phone:function(e){
    var phone = e.currentTarget.dataset.id
    wx.makePhoneCall({
      phoneNumber: phone //仅为示例，并非真实的电话号码
    })
  },
  mx_pay:function(e){
    var that = this
    var mx_info = e.currentTarget.dataset.id
    mx_info = mx_info.split('-')
    var title = mx_info[1]
     var id = mx_info[0]
    wx.navigateTo({
      url: 'pay?id='+id+'&title='+title,
    })
    // var mx_type = mx_info[3]
    // var fee = parseInt(mx_info[1])
    // var regNum=new RegExp('^[1-9]*[1-9][0-9]*$','g');
    // var rst = regNum.exec(fee)
   
    // if(rst === null){
    //    wx.showToast({
    //     title: '请输入大于0的数字',
    //     icon: 'success',
    //     duration: 2000
    //   })
    //   return false
    // }else{
    //   fee = parseInt(fee)
    // }
    // var id = mx_info[0]
    // var uid = this.data.uid
    // var openid = this.data.openid
    // var phone = this.data.phone
    // var msg_content = '感谢您对咚咚管家的支持，请在个人中心-我的返现里申请返现，返现处理到账时间为3个工作日。'
    //  wx.showModal({
    //     content: '确定支付？',
    //     showCancel: true,
    //     success: function (res) {
    //         if (res.confirm) {
    //             app.wxpay.pay(title,fee,openid,function(res){
    //             if(res.code==1){
    //               data.change_order(id,fee,mx_type,res.out_trade_no)
    //               that.order_info(uid,0)
    //               that.order_info(uid,1)
    //               that.order_info(uid,2)
    //               if(mx_type==1){
    //                 msg_content = title+'返现已生效，您可前往订单指定门店确定型号，请在平台支付余款后点击返现。';
    //                  that.setData({currentTab:1})
    //               }else if(mx_type==2){
    //                   that.setData({currentTab:1})
    //               }else{
    //                   that.setData({currentTab:2})
    //               }
    //               app.send_msg.send_msg(phone,msg_content,function(res){
    //                 wx.showToast({
    //                           title: '支付成功',
    //                           icon: 'success',
    //                           duration: 2000
    //                         })
    //               })
    //             }else{
    //               wx.showToast({
    //                 title: '支付失败',
    //                 icon: 'success',
    //                 duration: 2000
    //               })
    //             }
    //           })
    //         }
    //     }
    // })
  },
  /**
   * 取消订单
   */
  del_order:function(e){
    var that = this
    var uid = this.data.uid
     wx.showModal({
        content: '确定取消订单？',
        showCancel: true,
        success: function (res) {
            if (res.confirm) {
                var id = e.currentTarget.dataset.id
                data.del_order(id,function(data){
                    that.order_info(uid)
                })
            }
        }
    })
  },
  go_pj:function(e){
       var id = e.currentTarget.dataset.id
       var uid = this.data.uid
       wx.navigateTo({
         url: 'pj/index?id='+id+'&uid='+uid,
       })
  },
  /** 
     * 滑动切换tab 
     */  
  bindChange: function( e ) {  
    var that = this;  
    that.setData( { currentTab: e.detail.current });  
  },  
  /** 
   * 点击tab切换 
   */  
  swichNav: function( e ) {  
    var that = this;  
    if( this.data.currentTab === e.target.dataset.current ) {  
      return false;  
    } else {  
      that.setData( {  
        currentTab: e.target.dataset.current  
      })  
    }  
  },
  onShow:function(){
     app.util.getUserInfo(function(userInfo){
        data.get_new_xcx_order(userInfo.memberInfo.id,function(res){
            that.setData({all_list:res.all_list,dfk_list:res.dfk_list,dpj_list:res.dpj_list})
        })
    })
  }
})  