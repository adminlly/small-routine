var app = getApp()  
var data = require('../data/user.js')
var img_list = []
Page( {  
  data: {  
    /** 
        * 页面配置 
        */  
    winWidth: 0,  
    winHeight: 0,  
    // tab切换  
    currentTab: 0,  
    pic_path:app.pic_path,
    cd_id:'',
    up_img_list:[],
    order_list:[],
    bp_list:[],
    pic_num:0,
    user_info:[]
  },  
  onLoad: function() {  
    var that = this;  
    app.util.getUserInfo(function (user) {
       that.setData({
          user_info:user.memberInfo,
       })
       data.user_total_fx_price(user.memberInfo.id,function(res){
          that.setData({mx_price:res.data})
       })
       data.get_order_fx_list(user.memberInfo.id,0,function(res){
          that.setData({dsq_list:res.data})
       })
       data.get_order_fx_list(user.memberInfo.id,1,function(res){
          that.setData({fxz_list:res.data})
       })
       data.get_order_fx_list(user.memberInfo.id,2,function(res){
          that.setData({wzfx_list:res.data})
       })
     });
    /** 
     * 获取系统信息 
     */  
    wx.getSystemInfo( {  
      success: function( res ) {  
        that.setData( {  
          winWidth: res.windowWidth,  
          winHeight: res.windowHeight  
        });  
      }  
    });  
  },
  /**
   * 返现申请
   */
  sq_fx:function(e){
    var id = e.currentTarget.dataset.id
    var uid = this.data.user_info.id
    var that = this
    app.util.request({
        url: 'entry//user_sq_fx',
        data: {
            id:id,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
              var mx_data = res.data.data
              console.log(mx_data)
              var msg_contet = '您的'+mx_data.brand+'返现申请已受理，平台消费额为¥'+mx_data.total_price+', 返现比例为'+mx_data.fx_bl+'%, 返现具体金额为¥'+mx_data.total_fx_price+'。 返现完成 '
              var phone = that.data.user_info.phone
               app.send_msg.send_msg(phone,msg_contet,function(res){
                  wx.showToast({
                            title: '申请成功',
                            icon: 'success',
                            duration: 2000
                          })
                })
                data.get_order_fx_list(uid,0,function(res){
                    that.setData({dsq_list:res.data})
                })
                data.get_order_fx_list(uid,1,function(res){
                    that.setData({fxz_list:res.data,currentTab:1})
                })
            } else {
                failGo('数据获取失败');
            }
        }
    })
  },
  /** 
     * 滑动切换tab 
     */  
  bindChange: function( e ) {  
    var that = this;  
    that.setData( { currentTab: e.detail.current });  
  
  },  
  /** 
   * 点击tab切换 
   */  
  swichNav: function( e ) {  
    var that = this;  
    if( this.data.currentTab === e.target.dataset.current ) {  
      return false;  
    } else {  
      that.setData( {  
        currentTab: e.target.dataset.current  
      })  
    }  
  }
})  