// pages/user/index.js
var app = getApp()
Page({
  data:{
    header:'',
    nickName:'',
    uid:'',
    num:[]
  },
  onLoad:function(options){
    this.get_num()
  },
  get_num:function(){
    var that = this
     app.util.getUserInfo(function (user) {
       that.setData({
          header:user.memberInfo.header,
          nickName:user.memberInfo.nickname,
          uid:user.memberInfo.id,
          user_type:user.memberInfo.type
       })
       app.util.request({
          url: 'entry//get_order_status_num',
          data: {
              uid:user.memberInfo.id,
              m: 'qcp_ddgj',
          },
          cachetime: 0,
          success: function (res) {
              that.setData({mx_num:res.data.data})
          }
      })
      })
  },
  go_user_sc:function(){
       wx.navigateTo({
        url: 'sc/index'
      })
  },
  go_ybj_ty:function(){
    var user_type = this.data.user_type
      wx.navigateTo({
        url: 'ybj/index?user_type='+user_type
      })
  },
  go_dj_order:function(){
      wx.navigateTo({
        url: 'new_order?currentTab=0'
      })
  },
  go_yk_order:function(){
      wx.navigateTo({
        url: 'new_order?currentTab=1'
      })
  },
  go_pj_order:function(){
      wx.navigateTo({
        url: 'new_order?currentTab=2'
      })
  },
  go_tk_order:function(){
      wx.navigateTo({
        url: 'new_order?currentTab=3'
      })
  },
  go_to_fx:function(){
      wx.navigateTo({
        url: 'fx'
      })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
    if(this.data.uid!=''){
        this.get_num()
    }
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})