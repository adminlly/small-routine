// pages/user/pay.js
var app = getApp()
var data = require('../data/user.js')
Page({
  data:{},
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var id = options.id
    var title = options.title
    this.setData({id:id,title:title})
  },
  pay:function(e){
    var that = this
    var title = that.data.title
    app.util.getUserInfo(function(userInfo){
      var price = e.detail.value.price
      var regNum=new RegExp('[0-9]','g');
      var rst = regNum.exec(price)
      console.log(rst)
      if(rst === null){
        wx.showToast({
          title: '请输入大于0的数字',
          icon: 'success',
          duration: 2000
        })
        return false
      }
      var id = that.data.id
      app.wxpay.pay(title,price,userInfo.memberInfo.openid,function(res){
          if(res.code==1){
              app.util.request({
                  url: 'entry//order_pay',
                  data: {
                      id:id,
                      price:price,
                      m: 'qcp_ddgj',
                  },
                  cachetime: 0,
                  success: function (res) {
                    wx.redirectTo({
                        url:'success',
                    })
                  }
              })
          }else{
             wx.showToast({
              title: '付款失败',
              icon: 'success',
              duration: 2000
            })
          }
      })
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})