// pages/faybj/index.js
var app = getApp()
Page({
  data:{
    txt:'',
    mx_css:"",
    zhi:"none",
    pp_zhi:"none",
    html_view:[],
    brand_list:[],
    brand_type:[],
    xq_id:'',
    house_name:'',
    uid:'',
    index:0,
    zs_pl:0
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var txt = "问：成为样板间业主可以享受什么具体好处呢？\n答：申请成功的业主，可在团购价格基础上再享受10%-20%的优惠，具体优惠幅度根据业主实际购买商品型号而定。\n问：何谓样板间？\n答：样板间是指咚咚管家联合品牌家居商针对小区业主提供的线下产品展示空间。\n问：申请样板间需具备什么条件？\n答：用户所在小区为最长交付时间在1年以内的的。\n问：样板间申请成功需要多久？\n答：申请发送之后，平台会在三天时间和商家沟通完毕，并由平台客服安排商家和业主确定最终方案。\n问：相同业主或者地址是否可以申请多次样板间？\n答：同一位业主可按不同品类分别申请样板间，比如瓷砖、地板、定制家居、沙发等；但一个品类只可挑选一个品牌。\n问：样板间需要展示多久？ \n答：平均展示时间为1-3个月，准确信息根据业主和商家实际沟通而定。\n问：样板间主要向哪类人展示？ \n答：样板间只向同小区业主开放，如有特殊需求可致电平台客服025-86502697 沟通。\n";
    this.setData({txt:txt})
    this.setData({uid:app.globalData.uid})
    var that = this
    app.func.req('',{'op':'get_brand_type'},function(res){
      console.log(res)
          that.setData({
            brand_type:res.list
          })
      });
  },
  bindPickerChange: function(e) {
    this.setData({
      index: e.detail.value,
      zs_pl:e.detail.value
    })
  },
  EventHandle:function(e){
    var that = this
    var cs = e.currentTarget.id
    wx.getSystemInfo({
      success: function(res) {
        var mx_css = "width:"+res.windowWidth+"px;height:"+res.windowHeight+"px;"
        if(cs=='1'){
            that.setData({
              mx_css:mx_css,
              zhi:"show"
            })
        }else{
            that.setData({
              mx_css:mx_css,
              pp_zhi:"show"
            })
        }
      }
    })
  },
  close_show:function(e){
    var cs = e.currentTarget.id
    if(cs==1){
      this.setData({
        zhi:"none"
      })
    }else{
      this.setData({
        pp_zhi:"none"
     })
    }
  },//选择小区
  s_xq:function(e){
    var zhi = e.currentTarget.id
    zhi =  zhi.split("-");
    var xq_id = zhi[0];
    var house_name = zhi[1];
    this.setData({
      xq_id:xq_id,house_name:house_name,zhi:'none',ts_msg:house_name
    })
  },
  select_info:function(e){
    var that = this
    if(e.detail.value!=''){
      app.func.req('',{'op':'get_xq_info','mx_xq':e.detail.value},function(res){
          that.setData({
            html_view:res.list
          })
      });
    }
    
  },//选择品牌
  s_brand:function(e){
    var zhi = e.currentTarget.id
    zhi =  zhi.split("-");
    var b_id = zhi[0];
    var brand = zhi[1];
    this.setData({
      b_id:b_id,brand:brand,pp_zhi:'none',brand_msg:brand
    })
  },
  select_brand_info:function(e){
    var that = this
    if(e.detail.value!=''){
      app.func.req('',{'op':'get_brand_info','mx_brand':e.detail.value},function(res){
          that.setData({
            brand_list:res.list
          })
      });
    }
    
  },
  formSubmit:function(e){
      //console.log('form发生了submit事件，携带数据为：', e.detail.value)
      var data = e.detail.value
      var rst = true
      if(data.b_id == ''){
        wx.showToast({
          title: '请选择您所在的小区',
          icon: 'success',
          duration: 2000
        })
        rst = false
      }
      if(data.xq_id == ''){
        wx.showToast({
          title: '请选择家居品牌',
          icon: 'success',
          duration: 2000
        })
        rst = false
      }
      if(rst){
        app.func.req('?op=add_ybj',data,function(res){
          wx.showModal({
          title: '信息提示',
          content: '发布成功，我们会尽快帮您处理。是否继续发布？',
          success: function(res) {
            if (res.confirm) {
            }else{
               wx.navigateBack({
                delta: 1
              })
            }
          }
        })
      });
      }   
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})