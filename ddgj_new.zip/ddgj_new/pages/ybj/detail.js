// pages/ybj/detail.js
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp()
Page({
  data:{
    id:'',
    info:[],
    uid:'',
    header:'',
    cs:1,
    pic_path:app.pic_path,
    mr_sc:"../resources/sc1.png",
    pic_path:app.pic_path,
    btn_text:'返回拼团',
    phone:''
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
    var id = options.id
    // id = 9
    var cs = options.cs
    if(cs==2){
        this.setData({btn_text:'返回列表',cs:cs})
    }
    app.util.getUserInfo(function(res){
      that.setData({uid:res.memberInfo.id,header:res.memberInfo.header,phone:res.memberInfo.phone})
       app.util.request({
        url: 'entry//xcx_api',
        data: {
            id:id,
            uid:res.memberInfo.id,
            op:'ybj_detail',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
          var mx_data = res.data
          console.log(mx_data)
          wx.setNavigationBarTitle({
            title: mx_data.info.title
          })
          WxParse.wxParse('content', 'html', mx_data.info.content, that,5);  
          that.setData({info:mx_data.info,id:id,mr_sc:mx_data.info.mr_sc})
        }
    })
        
        
    })
  },
  /**
   * 收藏
   */
  my_sc:function(){
      // console.log(this.data.uid)
      var that = this
      var id = that.data.id
      var uid = that.data.uid
      app.util.request({
        url: 'entry//xcx_api',
        data: {
            id:id,
            uid:uid,
            op:'love_ybj',
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                  that.setData({mr_sc:"../resources/sc2.jpg"})
              } else {
                  that.setData({mr_sc:"../resources/sc1.png"})
              }
        }
      })
  },
   /**
   * 跳转到主页
   */
  go_home:function(){
      wx.switchTab({
        url: '/pages/index/index',
      })
  },
  /**
   * 跳转到个人中心
   */
  go_pl:function(){
      var id = this.data.id
      wx.navigateTo({
        url: '/pages/pl/index?id='+id,
      })
  },
  go_back:function(){
      var cs = this.data.cs
      if(cs==2){
          wx.switchTab({
            url: '/pages/ybj/index',
          })
      }else{
          wx.navigateBack({
            delta: 1, // 回退前 delta(默认为1) 页面
          })
      }
  },
  go_fx_detail:function(){
    var brand_id = this.data.info.brand_id
    wx.navigateTo({
        url: '/pages/fx/detail?id='+brand_id,
      })
  },
  go_yuyue:function(e){
    var zhi = e.currentTarget.dataset.id
    zhi = zhi.split('-')
    var id = zhi[0]
    var uid = zhi[1]
      wx.navigateTo({
        url: 'yuyue?id='+id+'&uid='+uid,
      })
  },
  add_order:function(e){
      wx.navigateTo({
        url: '/pages/pay/pay?id='+e.currentTarget.dataset.id,
      })
  },
  call_phone:function(){
    var phone = this.data.info.sj_phone
    wx.makePhoneCall({
      phoneNumber: phone //仅为示例，并非真实的电话号码
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})