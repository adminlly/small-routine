// pages/index/gd_sc.js
var app = getApp()
var data = require('../data/index.js')

Page({
  data:{},
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  go_gz:function(){
    wx.navigateTo({
      url: 'gd_gz',
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
    
   
  },
  onShareAppMessage: function() {
    return {
      title: '咚咚管家——共享美好，创造幸福', // 分享标题
      path: '/pages/index/index', // 分享路径
      success: function(res) {
        // 分享成功
        app.util.getUserInfo(function (user) {
          var uid = user.memberInfo.id
          data.fx_cm(uid,function(res){
            if(res.fx_msg!=''){
              wx.showToast({
                title: res.fx_msg,
                icon: 'success',
                duration: 2000
              })
            }
          });
        });
      },
      fail: function(res) {
        // 分享失败
      }
    }
    
  }
})