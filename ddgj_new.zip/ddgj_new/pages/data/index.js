var app = getApp()

function get_banner(cb){
    //console.log('焦点图');
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            cs:1,
            op:'get_banner_list',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function get_rx_fx(cb){
    //console.log('焦点图');
    app.util.request({
        url: 'entry//get_rx_fx',
        data: {
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function mx_get_love(cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            op:'get_love',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
             typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
//获取限时抢购的品牌
function get_xs_brand(cb){
    //console.log('焦点图');
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            cs:1,
            op:'get_xs_brand',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                var obj = res.data.data
                var end_time = obj.end_time + '000'
                show_time(end_time,function(data){
            // that.setData({dj_time:data})
                        obj.dj_time = data
                    typeof cb == "function" && cb(obj);
                })
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function get_zj_ybj(lat,lng,cb){
    //console.log('焦点图');
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            lat:lat,
            lng:lng,
            op:'get_zj_ybj',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
             typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function get_hot_list(obj,cb){
    //日期倒计时
     show_time(obj.end_time,function(data){
            // that.setData({dj_time:data})
            obj.dj_time = data
           typeof cb == "function" && cb(obj);
    })
}
/**
 * 倒计时
 */
function show_time(time_end,cb){ 
     var time_start = new Date().getTime(); //设定当前时间
     if(time_start>=time_end){
        var mx_obj = {}
        mx_obj.int_day = '00'
        mx_obj.int_hour = '00'
        mx_obj.int_minute = '00'
        mx_obj.int_second = '00'
        mx_obj.end = 1
        typeof cb == "function" && cb(mx_obj);
     }else{
        //var time_end =  new Date("2017/02/05 00:00:00").getTime(); //设定目标时间
        //console.log(new Date("2017/02/05 00:00:00").getTime())
        // 计算时间差 
        var time_distance = time_end - time_start; 
        // 天
        var int_day = Math.floor(time_distance/86400000) 
        time_distance -= int_day * 86400000; 
        // 时
        var int_hour = Math.floor(time_distance/3600000) 
        time_distance -= int_hour * 3600000; 
        // 分
        var int_minute = Math.floor(time_distance/60000) 
        time_distance -= int_minute * 60000; 
        // 秒 
        var int_second = Math.floor(time_distance/1000) 
        // 时分秒为单数时、前面加零 
        if(int_day < 10){ 
            int_day = "0" + int_day; 
        } 
        if(int_hour < 10){ 
            int_hour = "0" + int_hour; 
        } 
        if(int_minute < 10){ 
            int_minute = "0" + int_minute; 
        } 
        if(int_second < 10){
            int_second = "0" + int_second; 
        } 
        var mx_obj = {}
        mx_obj.int_day = int_day
        mx_obj.int_hour = int_hour
        mx_obj.int_minute = int_minute
        mx_obj.int_second = int_second
        mx_obj.end = -1
        //console.log(int_day+'-'+int_hour+"-"+int_minute+"-"+int_second)
        typeof cb == "function" && cb(mx_obj);
        setTimeout(function(){
        // console.log(time_start)
            show_time(time_end,function(data){
                typeof cb == "function" && cb(data);
            })
        },1000);
     }
}
function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.redirectTo({
                    url: '/pages/index/index'
                })
            }
        }
    })
}
function fx_cm(uid,cb){
    //console.log('焦点图');
    app.util.request({
        url: 'entry//prize',
        data: {
            uid:uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        }
    })
}
function get_gd_set(cb){
    app.util.request({
        url: 'entry//get_gd_set',
        data: {
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        }
    })
}
function gd_bm(uid,cb){
    app.util.request({
        url: 'entry//gd_bm',
        data: {
            uid:uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        }
    })
}
module.exports = {
    'show_time':show_time,
    'mx_get_love':mx_get_love,
    'get_zj_ybj':get_zj_ybj,
    'get_hot_list':get_hot_list,
    'get_banner': get_banner,
    'get_xs_brand':get_xs_brand,
    'get_rx_fx':get_rx_fx,
    'fx_cm':fx_cm,
    'get_gd_set':get_gd_set,
    'gd_bm':gd_bm,
    'failGo': failGo
};