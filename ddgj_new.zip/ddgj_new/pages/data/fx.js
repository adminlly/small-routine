var app = getApp()
/**
 * 返现列表 
 */
function xcx_fx_brand(cb){
    app.util.request({
        url: 'entry//xcx_fx_brand',
        data: {
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 获取品牌详情
 */
function get_brand_info(id,uid,cb){
    app.util.request({
        url: 'entry//brand_info',
        data: {
            id:id,
            uid,uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function xcx_fx_brand(cb){
    app.util.request({
        url: 'entry//xcx_fx_brand',
        data: {
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function xcx_fx_brand_pid(pl_id,cs,cb){
    app.util.request({
        url: 'entry//xcx_fx_brand',
        data: {
            cs:cs,
            pl_id:pl_id,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.redirectTo({
                    url: '/pages/index/index'
                })
            }
        }
    })
}

module.exports = {
    'xcx_fx_brand':xcx_fx_brand,
    'xcx_fx_brand_pid':xcx_fx_brand_pid,
    'get_brand_info':get_brand_info,
    'failGo': failGo
};