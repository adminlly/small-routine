var app = getApp()
/**
 * 拼团详情
 */
function get_brand_type(cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            op:'get_brand_type',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}

function get_ybj_list(cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            op:'get_ybj_list',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.redirectTo({
                    url: '/pages/index/index'
                })
            }
        }
    })
}

module.exports = {
    'get_brand_type': get_brand_type,
    'get_ybj_list':get_ybj_list,
    'failGo': failGo
};