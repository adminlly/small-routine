var app = getApp()

function get_brand_info(id,cb){
    app.util.request({
        url: 'entry//brand_info',
        data: {
            id:id,
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 支付订金，预订款，尾款
 * 1.订金
 * 2.预订款
 * 3.尾款
 */
function change_order(id,fee,mx_type,out_trade_no){
    app.util.request({
        url: 'entry//change_order',
        data: {
            id:id,
            fee:fee,
            mx_type:mx_type,
            out_trade_no:out_trade_no,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 根据订单的ID取消订单
 */
function del_order(id,cb){
    app.util.request({
        url: 'entry//del_order',
        data: {
            id:id,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}

function get_order(uid,status,cb){
    //console.log('焦点图');
    app.util.request({
        url: 'entry//xcx_order',
        data: {
            uid:uid,
            status:status,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function get_new_xcx_order(uid,cb){
    //console.log('焦点图');
    app.util.request({
        url: 'entry//get_new_xcx_order',
        data: {
            uid:uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 获取可返现订单列表
 * 用户的id,返现状态
 */
function get_order_fx_list(uid,is_fx,cb){
    app.util.request({
        url: 'entry//get_order_fx_list',
        data: {
            uid:uid,
            is_fx:is_fx,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 总消费金额，总返现金额
 */
function user_total_fx_price(uid,cb){
    app.util.request({
        url: 'entry//user_total_fx_price',
        data: {
            uid:uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 获取用户收藏列表
 */
function user_sc_list(uid,cb){
    app.util.request({
        url: 'entry//user_sc_list',
        data: {
            uid:uid,
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.redirectTo({
                    url: '/pages/index/index'
                })
            }
        }
    })
}

module.exports = {
    'get_order':get_order,
    'change_order':change_order,
    'del_order':del_order,
    'get_order_fx_list':get_order_fx_list,
    'user_total_fx_price':user_total_fx_price,
    'user_sc_list':user_sc_list,
    'get_new_xcx_order':get_new_xcx_order,
    'failGo': failGo
};