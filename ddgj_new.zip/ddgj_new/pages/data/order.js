var app = getApp()
/**
 * 品牌团购列表 
 */
function get_brand_info(id,cb){
    app.util.request({
        url: 'entry//brand_info',
        data: {
            id:id,
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function check_order(uid,id,mx_type,cb){
    app.util.request({
        url: 'entry//check_order',
        data: {
            id:id,
            uid:uid,
            mx_type:mx_type,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 生存订单
 */
function mx_add_order(obj,cb){
    app.util.request({
        url: 'entry//xcx_add_order',
        data: obj,
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 发送模板消息
 */
function xcx_send_msg(obj){
    var l = 'https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token=' + obj.access_token;  
    var d = {
        "touser": obj.openid,  
        "template_id": "3ll-uf_dk4V0Hby5ki47dhuYFbsvlsxV5vSxdb6-tRs", 
        "page": obj.page_url,          
        "form_id": obj.form_id,         
        "data": {
            "keyword1": {
                "value": "339208499", 
                "color": "#173177"
            }, 
            "keyword2": {
                "value": "2015年01月05日 12:30", 
                "color": "#173177"
            }, 
            "keyword3": {
                "value": "粤海喜来登酒店", 
                "color": "#173177"
            } , 
            "keyword4": {
                "value": "广州市天河区天河路208号", 
                "color": "#173177"
            } 
        },
        "emphasis_keyword": "keyword1.DATA" 
        }
    wx.request({  
      url: l,  
      data: d,  
      method: 'POST',  
      success: function(res){  
        console.log("push msg");  
        console.log(res);  
      },  
      fail: function(err) {  
        // fail  
        console.log("push err")  
        console.log(err);  
      }  
    });  
}
function xcx_access_token(cb){
    app.util.request({
        url: 'entry//xcx_access_token',
        data: {
             m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}

function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            
        }
    })
}
module.exports = {
    'get_brand_info':get_brand_info,
    'mx_add_order':mx_add_order,
    'xcx_access_token':xcx_access_token,
    'xcx_send_msg':xcx_send_msg,
    'failGo': failGo
};