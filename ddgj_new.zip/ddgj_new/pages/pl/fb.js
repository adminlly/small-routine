// pages/test/fb.js
var app = getApp()
Page({
  data:{
    id:'',
    uid:'',
    content:''
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var id = options.id
    var that = this
    app.util.getUserInfo(function (user) {
         var uid = user.memberInfo.id
         that.setData({id:id,uid:uid})
     });
  },
  get_content:function(e){
      var content = e.detail.value
      this.setData({content:content})
  },
  post:function(){
      var obj = {}
      obj.yid = this.data.id
      obj.uid = this.data.uid
      obj.pid = 0
      obj.content = this.data.content
      obj.m = 'qcp_ddgj'
      if(this.data.content == ''){
        wx.showToast({
          title: '评论不能为空',
          icon: 'success',
          duration: 2000
        })
        return false
      }
      app.util.request({
        url: 'entry//ybj_pl',
        data: obj,
        cachetime: 0,
        success: function (res) {
            wx.showToast({
              title: '发布成功',
              icon: 'success',
              duration: 1000
            })
            setTimeout(function(){
              wx.navigateBack({
                delta: 1, // 回退前 delta(默认为1) 页面
              })
            },1000)
        }
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})