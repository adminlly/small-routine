// pages/brand/detail.js
var data = require('../data/brand.js')
var app = getApp()
Page({
  data:{
    id:'',
    uid:'',
    info:{},
    pic_path:app.pic_path,
    dj_time:{},
    mr_sc:"../resources/sc1.png",
    show_m:"none",
    user_info:{},
    ybj_list:{},
    ybj_other_list:{},
    ybj_sh1:'none',
    ybj_sh2:'none',
    btn_text:'立即拼团',
    btn_style:'bf_r'
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
    var id = options.id
    //var id = 311
    app.util.getUserInfo(function (user) {
      //console.log(user)
      var uid = user.memberInfo.id
      data.get_brand_detail(id,uid,function (data) {
        //console.log(data.data)
        that.setData({info:data.data,mr_sc:data.data.mr_sc,id:id,uid:uid,user_info:user.memberInfo})
		  });
      //日期倒计时
      setTimeout(function(){
        //1486224000000
          data.show_time(that.data.info.end_time,function(data){
              if(data.end==1){
                  that.setData({btn_text:'拼团结束',btn_style:'bf_r n'})
              }
              that.setData({dj_time:data})
          })
      },1000);
      data.get_user_ybj(user.memberInfo.xq_id,function(ybj){
        if(ybj.list.length!=0){
            that.setData({ybj_sh1:'show'})
        }
        that.setData({ybj_list:ybj.list})
      })
      data.get_other_ybj(user.memberInfo.xq_id,function(ybj){
        if(ybj.list.length!=0){
            that.setData({ybj_sh2:'show'})
        }
        that.setData({ybj_other_list:ybj.list})
      })     
		});
  },
  /**
   * 支付订金弹窗
   */
  show_modal:function(){
    var that = this
    var id = that.data.id
    var rst = -1
    app.util.getUserInfo(function(userInfo){
        var uid = userInfo.memberInfo.id
        var phone = userInfo.memberInfo.phone
        if(phone==''){
            wx.showModal({title: '消息提示',content: '请先注册后后，方可参加团购',
              success: function(res) {
                if (res.confirm) {
                  wx.navigateTo({
                    url: '/pages/login/index'
                  })
                }
              }
            })
        }else{
            //检查是否已参加过
            data.check_ch_tg(id,uid,function(data){
                var code = data.code
                if(code!=1){
                  wx.showToast({
                    title: '亲！您已参加过团购',
                    icon: 'success',
                    duration: 2000
                  })
                  rst = -1
                }else{
                  that.setData({show_m:"show"})
                }
            })
        }
    })
  },
  mxPay:function(){
    
    //console.log(this.data.brand_info.brand+'---'+this.data.brand_info.dj_price)
    var title = this.data.info.item.brand
    var fee = this.data.info.item.dj_price
    var id = this.data.id
    var uid = this.data.uid
    var openid = this.data.user_info.openid
    var that = this
    app.wxpay.pay(title,fee,openid,function(res){
      if(res==1){
        that.add_order(id,uid,1,fee)
        wx.showToast({
          title: '支付成功',
          icon: 'success',
          duration: 2000
        })
        that.setData({show_m:"none"})
      }else{
        that.add_order(id,uid,0,fee)
        wx.showToast({
          title: '支付失败,请前往个人中心支付订金',
          icon: 'success',
          duration: 2000
        })
        that.setData({show_m:"none"})
      }
      
    })
  },
  add_order:function(id,uid,status,dj_price){
      var obj = {}
      obj.id = id
      obj.uid = uid
      obj.status = status
      obj.dj_price = dj_price
      obj.op = 'add_brand_order'
      obj.m = 'qcp_ddgj'
      data.mx_add_order(obj,function(res){})
  },
  close_modal:function(){
    this.setData({show_m:"none"})
  },
  /**
   * 跳转到主页
   */
  go_home:function(){
      wx.switchTab({
        url: '/pages/index/index',
      })
  },
  /**
   * 跳转到个人中心
   */
  go_user:function(){
      wx.switchTab({
        url: '/pages/user/index',
      })
  },
  /**
   * 收藏
   */
  my_sc:function(){
      // console.log(this.data.uid)
      var that = this
      var id = that.data.id
      var uid = that.data.user_info.id
      app.util.request({
        url: 'entry//xcx_api',
        data: {
            id:id,
            uid,uid,
            op:'brand_sc',
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                that.setData({mr_sc:"../resources/sc2.jpg"})
            } else {
                that.setData({mr_sc:"../resources/sc1.png"})
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
  },
  onReady:function(){
     // 页面渲染完成
    
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})