// pages/brand/new_index.js
var data = require('../data/brand.js')
var app = getApp()
Page({
  data:{
    pic_path:app.pic_path,
    list:[]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
    data.get_pp_list(function(res){
        console.log(res.list)
        that.setData({list:res.list})
    })
  },
  onReady:function(){
    // 生命周期函数--监听页面初次渲染完成
     //console.log(123222);
  },
  onShow:function(){
    // 生命周期函数--监听页面显示
   
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
   
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
    
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
   
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
    
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
    return {
      title: '拼团详情', // 分享标题
      desc: '欢迎来拼团列表页面', // 分享描述
      path: 'pages/brand/index' // 分享路径
    }
  }
})