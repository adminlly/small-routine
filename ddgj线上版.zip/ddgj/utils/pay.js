var md5 = require('pay_md5.js');
function pay(title,price,openid,cb){
    wx.request({
      url: 'https://xcx.dongdonggj.com/payapi.php',
      data: {'title':title,'price':price,'mx_openid':openid},
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function(res){
        // success
        //console.log(res)
        var payInfo = res.data
        var out_trade_no = payInfo.out_trade_no
        var appId = payInfo.appid;
        var timeStamp = (Date.parse(new Date()) / 1000).toString();
        var pkg = 'prepay_id=' + payInfo.prepay_id;
        var nonceStr = payInfo.nonce_str;
        var paySign = md5.hex_md5('appId='+appId+'&nonceStr='+nonceStr+'&package='+pkg+'&signType=MD5&timeStamp='+timeStamp+"&key=DongDongXiaoGuanJiaQianShuaiLiJ8").toUpperCase();
        wx.requestPayment({
          'timeStamp': timeStamp,
          'nonceStr': nonceStr,
          'package': pkg,
          'signType': 'MD5',
          'paySign': paySign,
          'success':function(res){
              var obj = {}
              obj.code = 1
              obj.out_trade_no = out_trade_no
              return typeof cb == "function" && cb(obj)
          },
          'fail':function(res){
              var obj = {}
              obj.code = 2
              obj.out_trade_no = out_trade_no
              return typeof cb == "function" && cb(obj)
          }
      });
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
}
/**
 * openid:用户的openid
 * amount:返现的金额
 * user_name:用户的姓名
 * desc:返现描述
 */
function pay_to_user(openid,amount,user_name,desc,cb){
    wx.request({
      url: 'https://xcx.dongdonggj.com/pay_to_user.php',
      data: {'amount':amount,'desc':desc,'openid':openid,'user_name':user_name},
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function(res){
            console.log(res.data)
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
}
module.exports = {
  pay: pay,
  pay_to_user:pay_to_user
}