var https = require('util.js') 

function send_message(phone,msg_content,cb){
   https.request({
        url: 'entry//xcx_send_message',
        data: {
            phone:phone,
            msg_content:msg_content,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.redirectTo({
                    url: '/pages/index/index'
                })
            }
        }
    })
}
module.exports = {
    'send_message':send_message,
    'failGo': failGo
};