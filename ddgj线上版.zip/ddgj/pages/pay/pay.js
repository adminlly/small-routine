// pages/brand/pay.js
var data = require('../data/order.js')
var app = getApp()
Page({
  data:{
    pic_path:app.pic_path,
    info:[],
    d_checked:'checked',
    ew_bt:2,
    id:'',
    uid:'',
    openid:'',
    access_token:'',
    phone:'',
    mx_dy:'none'
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
    var id = options.id
    //var id = 1492
    app.util.getUserInfo(function(userInfo){
          var user = userInfo.memberInfo
          if(user.name=='' || user.name==null){
              app.register()
          }else{
              data.get_brand_info(id,function(res){
                  that.setData({info:res.data,id:id,uid:user.id,openid:user.openid,phone:user.phone})
              })
          }
    })
  },
  switch1Change: function (e){
      this.setData({d_checked:'checked'})
  },
  switch2Change: function (e){
    var value =  e.detail.value
    var that = this
    if(value){
        this.setData({ew_bt:1})
    }else{
        this.setData({ew_bt:2})
    }
  },
  go_edit:function(){
      var uid = this.data.uid
      wx.navigateTo({
        url: 'phone?uid='+uid
      })
  },
  formSubmit:function(e){
    var that = this
    var title = this.data.info.brand
    var fee = this.data.info.dj_price
    fee = parseInt(fee)
    var id = this.data.id
    var uid = this.data.uid
    var openid = this.data.openid
    var ew_bt = this.data.ew_bt
    var phone = this.data.phone
    //1默认样板间返现2共享样板间返现
    var mx_type = 1
    if(ew_bt==1){
        mx_type = 2
    }
    //console.log(title+'-'+fee+'-'+id+'-'+uid+'-'+openid+'-'+mx_type)
    //return false
     wx.showModal({
        content: '确定购买？',
        showCancel: true,
        success: function (res) {
            if (res.confirm) {
                app.wxpay.pay(title,fee,openid,function(res){
                if(res.code==1){
                  that.add_order(id,uid,1,fee,mx_type,res.out_trade_no)
                      app.send_msg.send_msg(phone,'您已预订'+title+'的返现，请尽快完成预订款及尾款支付， 即可立即享受门店交易平台返现优惠。',function(res){
          wx.showToast({
                    title: '支付成功',
                    icon: 'success',
                    duration: 2000
                  })
                  setTimeout(function(){
                    wx.navigateBack({
                      delta: 1, // 回退前 delta(默认为1) 页面
                    })
                  },2000)
        })
                  //that.setData({show_m:"none"})
                }else{
                  that.add_order(id,uid,0,fee,mx_type,'')
                  app.send_msg.send_msg(phone,'您已预订'+title+'的返现，请尽快完成订金支付， 即可立即享受门店交易平台返现优惠。',function(res){
          wx.showToast({
                    title: '请前往个人中心支付订金',
                    icon: 'success',
                    duration: 2000
                  })
                  setTimeout(function(){
                    wx.navigateBack({
                      delta: 1, // 回退前 delta(默认为1) 页面
                    })
                  },2000)
        })
                }
                
              })
            }
        }
    })
  },
  send_msg:function(){
    data.xcx_access_token(function(res){
      var obj = {}
      obj.openid = that.data.openid
      obj.page_url = ''
      obj.form_id = e.detail.formId
      obj.access_token = res.access_token
      obj.title = title
      data.xcx_send_msg(obj)
    })
  },
  add:function(){
    var title = this.data.info.brand
    var fee = this.data.info.dj_price
    fee = parseInt(fee)
    var id = this.data.id
    var uid = this.data.uid
    var openid = this.data.openid
    var ew_bt = this.data.ew_bt
    //1默认样板间返现2共享样板间返现
    var mx_type = 1
    if(ew_bt==1){
        mx_type = 2
    }
     var that = this
     wx.showModal({
        content: '确定购买？',
        showCancel: true,
        success: function (res) {
            if (res.confirm) {
                app.wxpay.pay(title,fee,openid,function(res){
                if(res==1){
                  that.add_order(id,uid,1,fee,mx_type)
                  wx.showToast({
                    title: '支付成功',
                    icon: 'success',
                    duration: 2000
                  })
                  //that.setData({show_m:"none"})
                }else{
                  that.add_order(id,uid,0,fee,mx_type)
                  wx.showToast({
                    title: '支付失败,请前往个人中心支付订金',
                    icon: 'success',
                    duration: 2000
                  })
                  //that.setData({show_m:"none"})
                }
                
              })
            }
        }
    })
    //console.log(title+'-'+fee+'-'+id+'-'+uid+'-'+openid+'--'+mx_type)
  },
  add_order:function(id,uid,status,dj_price,mx_type,out_trade_no){
      var obj = {}
      obj.id = id
      obj.uid = uid
      obj.status = status
      obj.dj_price = dj_price
      obj.mx_type = mx_type
      obj.out_trade_no = out_trade_no
      obj.m = 'qcp_ddgj'
      data.mx_add_order(obj)
  },
  show_ot:function(){
    this.setData({mx_dy:'show'})
  },
  close_ot:function(){
    this.setData({mx_dy:'none'})
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
    var that = this
    app.util.getUserInfo(function(userInfo){
        var user = userInfo.memberInfo
        that.setData({phone:user.phone})
    })
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})