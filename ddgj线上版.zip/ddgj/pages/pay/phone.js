// pages/pay/phone.js
var app = getApp()
var data = require('../data/phone_area.js')
Page({
  data:{
    uid:'',
    index:0,
    phone_areas:data.phone_areas,
    pa:data.phone_areas[0]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var uid = options.uid
    this.setData({uid:uid})
  },
  formSubmit:function(e){
    var that = this
    var uid = that.data.uid
    var phone = e.detail.value.phone
    var myreg = /^(((13[0-9]{1})|(14[0-9]{1})|(17[0]{1})|(15[0-3]{1})|(15[5-9]{1})|(18[0-9]{1}))+\d{8})$/;
    var phone_area = e.detail.value.phone_area
    if(phone==''){
        wx.showToast({title: '手机号码不能为空',icon: 'success',duration: 2000})
        return false
    }else if(phone.length !=11){
        wx.showToast({title: '请输入有效的手机号码！',icon: 'success',duration: 2000})
       return false
    }else if(!myreg.test(phone)){
        wx.showToast({title: '请输入正确的手机号码！',icon: 'success',duration: 2000})
       return false
    }
    app.util.request({
        url: 'entry//xcx_edit_phone',
        data: {
            uid:uid,
            phone:phone,
            phone_area:phone_area,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if(res.data.code==1){
                wx.navigateBack()
            }
        }
      })
  },
  bindPickerChange: function(e) {
    var zhi = this.data.phone_areas[e.detail.value]
    this.setData({
      index: e.detail.value,
      pa:zhi
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})