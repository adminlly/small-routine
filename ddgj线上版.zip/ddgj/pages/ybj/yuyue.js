var arr = []
var data = require('../data/ybj_config.js')
const conf = {
  data: {
    hasEmptyGrid: false,
    mr_time:'点击选择:',
    mr_date:'点击选择>',
    mx_arr:[],
    set_zhi:[],
    time:'9:00',
    ms:''
  },
  getSystemInfo() {
    try {
      const res = wx.getSystemInfoSync();
      this.setData({
        scrollViewHeight: res.windowHeight * res.pixelRatio || 667
      });
    } catch (e) {
      console.log(e);
    }
  },
  getThisMonthDays(year, month) {
    return new Date(year, month, 0).getDate();
  },
  getFirstDayOfWeek(year, month) {
    return new Date(Date.UTC(year, month - 1, 1)).getDay();
  },
  calculateEmptyGrids(year, month) {
    const firstDayOfWeek = this.getFirstDayOfWeek(year, month);
    let empytGrids = [];
    if (firstDayOfWeek > 0) {
      for (let i = 0; i < firstDayOfWeek; i++) {
        empytGrids.push(i);
      }
      this.setData({
        hasEmptyGrid: true,
        empytGrids
      });
    } else {
      this.setData({
        hasEmptyGrid: false,
        empytGrids: []
      });
    }
  },
  calculateDays(year, month) {
    let days = [];

    const thisMonthDays = this.getThisMonthDays(year, month);
    let mx_days = []
    for (let i = 1; i <= thisMonthDays; i++) {
      var old_day = {}
      old_day.mx_num= i;
      old_day.cs = '';
      days.push(i);
      mx_days.push(old_day);
    }
    //console.log(mx_days)
    this.setData({
      days,
      mx_days
    });
  },
  onLoad(options) {
    var id = options.id
    var yz_uid = options.uid
    // console.log('样板间的id'+id)
    // var id = 9
    // var yz_uid = 2
    const date = new Date();
    const cur_year = date.getFullYear();
    const cur_month = date.getMonth() + 1;
    const mx_day = date.getDate()
    const weeks_ch = ['日', '一', '二', '三', '四', '五', '六'];
    this.calculateEmptyGrids(cur_year, cur_month);
    this.calculateDays(cur_year, cur_month);
    this.getSystemInfo();
    var app = getApp()
    var that = this
    that.setData({
          cur_year,
          cur_month,
          mx_day,
          weeks_ch
    })
    app.util.getUserInfo(function(res){
        that.mx_ybj_config(yz_uid,cur_year,cur_month)
      //console.log(cur_year+'--'+cur_month+'--'+weeks_ch)
        that.setData({uid:res.memberInfo.id,phone:res.memberInfo.phone,jc_name:res.memberInfo.jc_name,id:id,yz_uid:yz_uid})
        app.util.request({
          url: 'entry//xcx_api',
          data: {
              id:id,
              uid:res.memberInfo.id,
              op:'ybj_detail',
              m: 'qcp_ddgj',
          },
          cachetime: 30,
          success: function (mx_info) {
            that.setData({ybj_info_title:mx_info.data.info.brand,ybj_info_area:mx_info.data.info.mx_house_name})
          }
      })
    })
    data.get_user_phone(yz_uid,function(res){
        that.setData({yz_phone:res.phone,yz_name:res.name})
    })
  },
  mx_ybj_config:function(uid,cur_year,cur_month){
    var that = this
    data.get_ybj_config(uid,cur_year,cur_month,function(info){
        var new_arr = []
        if(info.data!=false){
            new_arr = JSON.parse(info.data)
        }
        arr = new_arr
        var mx_days = that.data.mx_days
        var new_mx_days = []
        for(var i in mx_days){
            var num = mx_days[i].mx_num
            var mx_arr = {}
            mx_arr.mx_num = num
            if(new_arr.indexOf(num)!=-1){
                mx_arr.cs = 'mx_red'
            }else{
                mx_arr.cs = ''
            }
            new_mx_days.push(mx_arr)
        }
        that.setData({mx_days:new_mx_days,set_zhi:new_arr})
    })
  },
  onShow(){
    var app = getApp()
    var that = this
      app.util.getUserInfo(function(res){
        that.setData({phone:res.memberInfo.phone})
      })
  },
  bindDateChange(e) {
    this.setData({
      date: e.detail.value,
      mr_date:''
    })
  },
  bindTimeChange: function(e) {
    this.setData({
      time: e.detail.value,
      mr_time: ''
    })
  },
  handleCalendar(e) {
    const handle = e.currentTarget.dataset.handle;
    const cur_year = this.data.cur_year;
    const cur_month = this.data.cur_month;
    var uid = this.data.uid
    if (handle === 'prev') {
      let newMonth = cur_month - 1;
      let newYear = cur_year;
      if (newMonth < 1) {
        newYear = cur_year - 1;
        newMonth = 12;
      }

      this.calculateDays(newYear, newMonth);
      this.calculateEmptyGrids(newYear, newMonth);
      this.mx_ybj_config(uid,newYear,newMonth)
      this.setData({
        cur_year: newYear,
        cur_month: newMonth
      })

    } else {
      let newMonth = cur_month + 1;
      let newYear = cur_year;
      if (newMonth > 12) {
        newYear = cur_year + 1;
        newMonth = 1;
      }

      this.calculateDays(newYear, newMonth);
      this.calculateEmptyGrids(newYear, newMonth);
      this.mx_ybj_config(uid,newYear,newMonth)
      this.setData({
        cur_year: newYear,
        cur_month: newMonth
      })
    }
  },
  add(){
    var app = getApp()
    var cg_date = this.data.date
    var cg_time = this.data.time
    if(cg_date==undefined){
        wx.showToast({
          title: '参观日期不能为空',
          icon: 'success',
          duration: 2000
        })
        return false
    }else{
        var cg_date_arr = cg_date.split('-')
        var new_date = cg_date_arr[0]+'年'+cg_date_arr[1]+'月'+cg_date_arr[2]+'日'+' '+cg_time
        if(arr.indexOf(parseInt(cg_date_arr[2]))==-1){
            wx.showToast({
              title: '当前日期样板间不对外开放',
              icon: 'success',
              duration: 2000
            })
            return false
        }
    }
    var obj = {}
    obj.uid = this.data.uid
    obj.cg_date = cg_date
    obj.cg_time = cg_time
    obj.m = 'qcp_ddgj'
    obj.yid = this.data.id
    var phone = this.data.phone
    var ybj_info_title = this.data.ybj_info_title
    var msg_content = "您预约"+ybj_info_title+"样板间,"+new_date+"参观的需求已受理，请等待房主确认。";
    /**
     * 样板间业主用户预约短信提醒
     */
    var yz_phone = this.data.yz_phone
    var yz_msg_content = "亲爱的"+this.data.yz_name+"，您同小区的邻居"+this.data.jc_name+"已经预约了您位于"+this.data.ybj_info_area+ybj_info_title+"样板间，预约参观时间是"+new_date+"，请尽快处理确认。";
    app.util.request({
        url: 'entry//add_yuyue',
        data: obj,
        cachetime: 0,
        success: function (res) {
          app.send_msg.send_msg(phone,msg_content,function(res){
             app.send_msg.send_msg(yz_phone,yz_msg_content,function(res1){
                wx.showToast({
                title: '预约成功',
                icon: 'success',
                duration: 2000
              })
              setTimeout(function(){
                wx.navigateBack({
                  delta: 1, // 回退前 delta(默认为1) 页面
                })
              },2000)
             })
          })
        }
    })
  },
  change_phone(){
    var uid = this.data.uid
    wx.navigateTo({
      url: '/pages/pay/phone?uid='+uid,
    })
  },
  call_phone(){
      var phone = this.data.yz_phone
      wx.makePhoneCall({
        phoneNumber: phone //仅为示例，并非真实的电话号码
      })
  },
  onShareAppMessage() {
    return {
      title: '小程序日历',
      desc: '还是新鲜的日历哟',
      path: 'pages/index/index'
    }
  }
};

Page(conf);