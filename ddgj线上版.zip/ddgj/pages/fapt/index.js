// pages/fapt/index.js
var utils = require('../../utils/util.js')
var app = getApp()
Page({
  data:{
    default_start_time:"",
    default_end_time:"",
    mx_css:"",
    zhi:"none",
    pp_zhi:"none",
    html_view:[],
    brand_list:[],
    brand_type:[],
    xq_id:'',
    house_name:'',
    ts_msg:'请选择您所在的小区',
    brand_msg:"请选择家居品牌",
    uid:'',
    index:0,
    jj_pl:0,
    brand:'',
    b_id:'',
    start_time:'',
    end_time:''
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
    this.setData({uid:app.globalData.uid})
    this.setData({
      default_start_time:utils.formatTime(new Date(),2),
      default_end_time:utils.addDate(utils.formatTime(new Date(),2),30),
      start_time:utils.formatTime(new Date(),2),
      end_time:utils.addDate(utils.formatTime(new Date(),2),30)
      })
    app.func.req('',{'op':'get_brand_type'},function(res){
          that.setData({
            brand_type:res.list
          })
      });
  },
  bindPickerChange: function(e) {
    this.setData({
      index: e.detail.value,
      jj_pl:e.detail.value
    })
  },
  bindStartDateChange: function(e) {
    this.setData({
      default_start_time: e.detail.value,
      start_time: e.detail.value
    })
  },
  bindEndDateChange: function(e) {
    this.setData({
      default_end_time: e.detail.value,
      end_time:e.detail.value
    })
  },
  EventHandle:function(e){
    var that = this
    var cs = e.currentTarget.id
    wx.getSystemInfo({
      success: function(res) {
        var mx_css = "width:"+res.windowWidth+"px;height:"+res.windowHeight+"px;"
        if(cs=='1'){
            that.setData({
              mx_css:mx_css,
              zhi:"show"
            })
        }else{
            that.setData({
              mx_css:mx_css,
              pp_zhi:"show"
            })
        }
      }
    })
  },
  close_show:function(e){
    var cs = e.currentTarget.id
    if(cs==1){
      this.setData({
        zhi:"none"
      })
    }else{
      this.setData({
        pp_zhi:"none"
     })
    }
  },//选择小区
  s_xq:function(e){
    var zhi = e.currentTarget.id
    zhi =  zhi.split("-");
    var xq_id = zhi[0];
    var house_name = zhi[1];
    this.setData({
      xq_id:xq_id,house_name:house_name,zhi:'none',ts_msg:house_name
    })
  },
  select_info:function(e){
    var that = this
    if(e.detail.value!=''){
      app.func.req('',{'op':'get_xq_info','mx_xq':e.detail.value},function(res){
          that.setData({
            html_view:res.list
          })
      });
    }
    
  },//选择品牌
  s_brand:function(e){
    var zhi = e.currentTarget.id
    zhi =  zhi.split("-");
    var b_id = zhi[0];
    var brand = zhi[1];
    this.setData({
      b_id:b_id,brand:brand,pp_zhi:'none',brand_msg:brand
    })
  },
  select_brand_info:function(e){
    var that = this
    if(e.detail.value!=''){
      app.func.req('',{'op':'get_brand_info','mx_brand':e.detail.value},function(res){
          that.setData({
            brand_list:res.list
          })
      });
    }
    
  },
  formSubmit:function(e){
      //console.log('form发生了submit事件，携带数据为：', e.detail.value)
      var data = e.detail.value
      var rst = true
      if(data.xq_id == ''){
        wx.showToast({
          title: '请选择您所在的小区',
          icon: 'success',
          duration: 2000
        })
        rst = false
      }
      if(data.b_id == ''){
        wx.showToast({
          title: '请选择家居品牌',
          icon: 'success',
          duration: 2000
        })
        rst = false
      }
      if(rst){
        app.func.req('?op=add_brand_info',data,function(res){
          wx.showModal({
          title: '信息提示',
          content: '发布成功，我们会尽快帮您处理。是否继续发布？',
          success: function(res) {
            if (res.confirm) {
            }else{
               wx.navigateBack({
                delta: 1
              })
            }
          }
        })
      });
      }   
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})