var data = require('../data/brand.js')
var app = getApp()
Page({
  data:{
    list:[],
    pic_path:app.pic_path,
    img_url:"http://3g.dongdonggj.com/attachment/",
  },
  onLoad:function(options){
    // 生命周期函数--监听页面加载
    var that = this
    var pl = '';
    if(options.pl!=undefined){
        pl=options.pl;
    }
    that.get_list(pl)
  },
  get_list:function(pl){
    var that = this
    data.get_list(pl,function(res){
      that.setData({list:res.list})
    })
  },
  onReady:function(){
    // 生命周期函数--监听页面初次渲染完成
     
  },
  onShow:function(){
    // 生命周期函数--监听页面显示
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
   
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
    
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
   
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
    
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
    return {
      title: 'title', // 分享标题
      desc: 'desc', // 分享描述
      path: 'path' // 分享路径
    }
  }
})