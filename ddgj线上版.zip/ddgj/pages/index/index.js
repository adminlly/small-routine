var data = require('../data/index.js')
var app = getApp()
Page({
   data: {
    imgUrls: [],
    jk_url:"https://3g.dongdonggj.com/app/index.php?i=16&c=entry&do=wxxcx&m=qcp_ddgj",
    img_url:"http://3g.dongdonggj.com/attachment/",
    indicatorDots: true,
    pic_path:app.pic_path,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    tg_list:[],//十天拼团
    sp_list:[],//爆品
    ybj_list:[],//样板间列表
    xs_tg_list:{},
  },
  onLoad:function(options){
    // 生命周期函数--监听页面加载
    var that = this
    app.util.getUserInfo(function (user) {
        var info = user.memberInfo
        that.setData({uid:info.id})
    });
     /**获取焦点图 */
     data.get_banner(function(data){
       that.setData({imgUrls:data.list})
     })
     data.get_gd_set(function(res){
       that.setData({gd_info:res.data})
     })
     wx.getLocation({
      type: 'wgs84',
      success: function(res) {
        var lat = res.latitude
        var lng = res.longitude
        data.get_zj_ybj(lat,lng,function(data){
          that.setData({ybj_list:data.ybj_list})
        })
      }
    })
     
    //获取猜你喜欢列表
     that.get_love()
  },
  get_love:function(){
    var that = this
    data.get_xs_brand(function(data){
         that.setData({xs_tg_list:data})
    })
    data.get_rx_fx(function(res){
        that.setData({rx_fx_list:res.data})
    })
    data.mx_get_love(function(res){
      that.setData({tg_list:res.tg_list})
      //日期倒计时
      var list = {}
      setTimeout(function(){
          data.get_hot_list(res.tg_list[0],function(data){
              list[0] = data
          })
          data.get_hot_list(res.tg_list[1],function(data){
              list[1] = data
          })
          data.get_hot_list(res.tg_list[2],function(data){
              list[2] = data
          })
          data.get_hot_list(res.tg_list[3],function(data){
              list[3] = data
              that.setData({tg_list:list})
          })
          
        },1000);
    });
  },
  go_more:function(){
    wx.navigateTo({
      url: 'more',
    })
  },
  go_ybj:function(){
    wx.switchTab({
      url: '/pages/ybj/index',
    })
  },
  onReady:function(){
    // 生命周期函数--监听页面初次渲染完
  },
  go_h5:function(e){
    app.util.getUserInfo(function (user) {
        var user_info = user.memberInfo
        if(user_info.name=='' || user_info.name == null){
           app.register()
        }else{
          data.gd_bm(user_info.id,function(res){
            wx.navigateTo({
              url: 'gd_sc',
            })
          })
        }
    });
  },
  onShow:function(){
    // 生命周期函数--监听页面显示
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
    this.get_love()
    console.log("用户下拉操作")
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
    var uid = this.data.uid
    return {
      title: '咚咚管家——共享美好，创造幸福', // 分享标题
      path: '/pages/index/index', // 分享路径
      success: function(res) {
      },
      fail: function(res) {
        // 分享失败
      }
    }
  }
})