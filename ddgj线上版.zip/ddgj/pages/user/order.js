// pages/user/order.js
var app = getApp()
Page({
  data:{
    order_status: ['全部', '代付订金', '优惠发布', '待付余款','待收货','交易完成'],
    index:0,
    brand_list:[],
    sp_list:[],
    sy_price:'',
    sp_sy_price:'',
    uid:'',
    status:0,
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    //console.log(app.globalData.uid)
    var status = options.status
    status = parseInt(status) + 1
    this.setData({uid:app.globalData.uid,status:status})
    this.get_list(app.globalData.uid,status-1)
  },
  bindPickerChange:function(e){
    var status = e.detail.value
    this.get_list(this.data.uid,status-1)
    this.setData({status:status})
  },
  get_list:function(uid,status){
      var that = this
    app.func.req('',{'op':'get_user_order_list','uid':uid,'status':status},function(res){
      //console.log(res)
        that.setData({
          brand_list:res.brand_list,
          sp_list:res.sp_list
        })
    });
  },
  get_sy_price:function(e){
    var sy_price = e.detail.value
    var regNum=new RegExp('[0-9]','g');
    var rgNum=regNum.test(sy_price);
    if(rgNum){
       this.setData({
          sy_price: sy_price
      })
    }else{
      wx.showToast({
        title: '金额只能为数字',
        icon: 'success',
        duration: 2000
      })
    }
  },
  sp_sy_price:function(e){
    var sy_price = e.detail.value
    var regNum=new RegExp('[0-9]','g');
    var rgNum=regNum.test(sy_price);
    if(rgNum){
       this.setData({
          sp_sy_price: sy_price
      })
    }else{
      wx.showToast({
        title: '金额只能为数字',
        icon: 'success',
        duration: 2000
      })
    }
  },
  mxPay:function(e){
    //console.log(this.data.id+'---'+this.data.uid)
    //console.log(e.currentTarget.dataset.id)
    var fee = this.data.sy_price
    if(fee==''){
        wx.showToast({
        title: '金额不能为空',
        icon: 'success',
        duration: 2000
      })
      return false
    }
    var data = e.currentTarget.dataset.id
    data = data.split("-");
    var id = data[0];
    var title = data[1];
    var uid = this.data.uid
    var status = this.data.status
    var openid = app.globalData.openid
    var that = this
    app.wxpay.pay(title,fee,openid,function(res){
      if(res==1){
        that.user_pay_sy_price(id,fee)
        wx.showToast({
          title: '支付成功',
          icon: 'success',
          duration: 2000
        })
        that.get_list(uid,3)
        that.setData({status:4})
      }else{
        wx.showToast({
          title: '支付失败',
          icon: 'success',
          duration: 2000
        })
      }
      
    })
  },
  user_pay_sy_price:function(id,sy_price){
      var that = this
      app.func.req('',{'op':'user_pay_sy_price','uid':that.data.uid,'id':id,'sy_price':sy_price},function(res){
        //console.log(res)
      });
  },
  sp_mxPay:function(e){
    //console.log(this.data.id+'---'+this.data.uid)
    //console.log(e.currentTarget.dataset.id)
    var fee = this.data.sp_sy_price
    if(fee==''){
        wx.showToast({
        title: '金额不能为空',
        icon: 'success',
        duration: 2000
      })
      return false
    }
    var data = e.currentTarget.dataset.id
    data = data.split("-");
    var id = data[0];
    var title = data[1];
    var uid = this.data.uid
    var status = this.data.status
    var openid = app.globalData.openid
    var that = this
    app.wxpay.pay(title,fee,openid,function(res){
      if(res==1){
        that.user_sp_pay_sy_price(id,fee)
        wx.showToast({
          title: '支付成功',
          icon: 'success',
          duration: 2000
        })
        that.get_list(uid,3)
        that.setData({status:4})
      }else{
        wx.showToast({
          title: '支付失败',
          icon: 'success',
          duration: 2000
        })
      }
      
    })
  },
  user_sp_pay_sy_price:function(id,sy_price){
      var that = this
      app.func.req('',{'op':'user_sp_pay_sy_price','uid':that.data.uid,'id':id,'sy_price':sy_price},function(res){
        //console.log(res)
      });
  },
  brand_sh:function(e){
    // 品牌收货
     var that = this
     var id = e.currentTarget.dataset.id
     var uid = this.data.uid
     var status = this.data.status
      app.func.req('',{'op':'brand_sh','uid':uid,'id':id},function(res){
        //console.log(res)
        that.get_list(uid,4)
        that.setData({status:5})
      });
  },
  sp_sh:function(e){
    // 品牌收货
     var that = this
     var id = e.currentTarget.dataset.id
     var uid = this.data.uid
     var status = this.data.status
      app.func.req('',{'op':'sp_sh','uid':uid,'id':id},function(res){
        //console.log(res)
        that.get_list(uid,4)
        that.setData({status:5})
      });
  },
  to_brand:function(){
      wx.switchTab({
        url: '/pages/brand/index'
      })
  },
  to_sp:function(){
      wx.switchTab({
        url: '/pages/bp/index'
      })
  },
  brand_pay_dj:function(e){
      var data = e.currentTarget.dataset.id
      //console.log(data)
      data = data.split("-");
      var id = data[0];
      var fee = data[1];
      var title = data[2];
      var uid = this.data.uid
      var status = this.data.status
      var openid = app.globalData.openid
      var that = this
      app.wxpay.pay(title,fee,openid,function(res){
        if(res==1){
          that.user_pay_dj(id,fee)
          wx.showToast({
            title: '支付成功',
            icon: 'success',
            duration: 2000
          })
        that.get_list(uid,1)
        that.setData({status:2})
      }else{
        wx.showToast({
          title: '支付失败',
          icon: 'success',
          duration: 2000
        })
      }
      
    })
  },
  user_pay_dj:function(id,dj_price){
      var that = this
      app.func.req('',{'op':'user_pay_dj','uid':that.data.uid,'id':id,'dj_price':dj_price},function(res){
        //console.log(res)
      });
  },
  sp_pay_dj:function(e){
      var data = e.currentTarget.dataset.id
      //console.log(data)
      data = data.split("-");
      var id = data[0];
      var fee = parseInt(data[1]);
      var title = data[2];
      var uid = this.data.uid
      var status = this.data.status
      var openid = app.globalData.openid
      var that = this
      app.wxpay.pay(title,fee,openid,function(res){
        if(res==1){
          that.user_sp_pay_dj(id,fee)
          wx.showToast({
            title: '支付成功',
            icon: 'success',
            duration: 2000
          })
        that.get_list(uid,2)
        that.setData({status:3})
      }else{
        wx.showToast({
          title: '支付失败',
          icon: 'success',
          duration: 2000
        })
      }
      
    })
  },
  user_sp_pay_dj:function(id,dj_price){
      var that = this
      app.func.req('',{'op':'user_sp_pay_dj','uid':that.data.uid,'id':id,'dj_price':dj_price},function(res){
        //console.log(res)
      });
  },
  yhfb:function(e){
    console.log(e)
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: 'yhfb?id='+id
    })
  },
  jyfs:function(e){
    console.log(e)
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: 'jyfs?id='+id
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})