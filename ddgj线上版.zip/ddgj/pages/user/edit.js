// pages/user/edit.js
var app = getApp()
Page({
  data:{
    user_info:[]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
     app.util.getUserInfo(function (user) {
       //console.log(user)
       that.setData({
          user_info:user.memberInfo
       })
     });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})