// pages/user/pj/index.js
var app = getApp()
Page({
  data:{
    mr_xing:['../../resources/sc1.png','../../resources/sc1.png','../../resources/sc1.png','../../resources/sc1.png','../../resources/sc1.png'],
    xz_xing:['../../resources/sc2.jpg','../../resources/sc2.jpg','../../resources/sc2.jpg','../../resources/sc2.jpg','../../resources/sc2.jpg'],
    jk_url:"https://xcx.dongdonggj.com/app/index.php?i=16&c=entry&do=android_interface&m=qcp_ddgj",
    content:'',
    xing:0,
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var id = options.id
    var uid = options.uid
    console.log(id+'--'+uid)
    this.setData({id:id,uid:uid})
  },
  get_xing:function(e){
      var mr_zhi = 5
      var zhi = e.currentTarget.dataset.id
      zhi = zhi+1
      var sy_zhi = mr_zhi-zhi
      var cz_xing = []
      for(var i = 0;i<zhi ;i++){
          cz_xing.push('../../resources/sc2.jpg')
      }
      for(var i = 0;i < sy_zhi ; i++){
          cz_xing.push('../../resources/sc1.png')
      }
      this.setData({mr_xing:cz_xing,xing:zhi})
  },
  get_text:function(e){
    this.setData({content:e.detail.value})
  },
  fb:function(){
    if(this.data.xing==0){
        wx.showToast({
          title: '请先打分',
          icon: 'success',
          duration: 2000
        })
        return false
    }
    if(this.data.content==''){
        wx.showToast({
          title: '评价内容不能为空',
          icon: 'success',
          duration: 2000
        })
        return false
    }
    var obj = {}
    obj.xing = this.data.xing
    obj.content = this.data.content
    obj.picture = this.data.picture
    obj.order_id = this.data.id
    obj.uid = this.data.uid
    obj.m = 'qcp_ddgj'
    app.util.request({
        url: 'entry//order_pj',
        data: obj,
        cachetime: 0,
        success: function (res) {
            wx.showToast({
              title: '发布成功',
              icon: 'success',
              duration: 2000
            })
            wx.navigateBack({
              delta: 1, // 回退前 delta(默认为1) 页面
            })
        }
    })
  },
  /**
   * 上传图片
   */
  up_img:function(e){
    var url = this.data.jk_url+"&op=upload_img";
    var that = this
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
         var tempFilePaths = res.tempFilePaths
         var len = tempFilePaths.length
         var img_arr = []
         for(var i = 0; i< len ; i++){
             wx.uploadFile({
              url: url, //上传文件接口地址
              filePath: tempFilePaths[i],
              name: 'file',
              formData:{
                'id':'123',
                'user': 'test'
              },
              success: function(res){
                var data = JSON.parse(res.data)
                //do something
                console.log(data)
                if(data.code==-3){
                    wx.showToast({
                      title: '图片过大，上传失败',
                      icon: 'success',
                      duration: 2000
                    })
                    return false
                }
                if(data.code==-2){
                    wx.showToast({
                      title: '图片已存在',
                      icon: 'success',
                      duration: 2000
                    })
                    return false
                }
                if(data.code==-5){
                    wx.showToast({
                      title: '图片上传失败',
                      icon: 'success',
                      duration: 2000
                    })
                    return false
                }
                img_arr.push(data.data)
                that.setData({img_arr:img_arr,picture:data.data})
              }
            })
         }
      }
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})