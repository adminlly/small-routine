var arr = []
var data = require('../../data/ybj_config.js')
var data_arr = []
const conf = {
  data: {
    hasEmptyGrid: false,
    mr_time:'点击选择>',
    mr_date:'点击选择>',
    mx_arr:[],
    set_zhi:[],
    ms:'',
    month_hidden:true,
    week_hidden:true,
    weekNum:[{id:'1',title:'周日'},{id:'2',title:'周一'},{id:'3',title:'周二'},{id:'4',title:'周三'},{id:'5',title:'周四'},{id:'6',title:'周五'},{id:'7',title:'周六'},{}],
    mx_month:[{id:'1',title:'一月份'},{id:'2',title:'二月份'},{id:'3',title:'三月份'},{id:'4',title:'四月份'},{id:'5',title:'五月份'},{id:'6',title:'六月份'},{id:'7',title:'七月份'},{id:'8',title:'八月份'},{id:'9',title:'九月份'},{id:'10',title:'十月份'},{id:'11',title:'十一月份'},{id:'12',title:'十二月份'},{}],
    select_month_title:'请选择',
    select_week_title:'请选择'
  },
  getSystemInfo() {
    try {
      const res = wx.getSystemInfoSync();
      this.setData({
        scrollViewHeight: res.windowHeight * res.pixelRatio || 667
      });
    } catch (e) {
      console.log(e);
    }
  },
  getThisMonthDays(year, month) {
    return new Date(year, month, 0).getDate();
  },
  getFirstDayOfWeek(year, month) {
    return new Date(Date.UTC(year, month - 1, 1)).getDay();
  },
  calculateEmptyGrids(year, month) {
    const firstDayOfWeek = this.getFirstDayOfWeek(year, month);
    let empytGrids = [];
    if (firstDayOfWeek > 0) {
      for (let i = 0; i < firstDayOfWeek; i++) {
        empytGrids.push(i);
      }
      this.setData({
        hasEmptyGrid: true,
        empytGrids
      });
    } else {
      this.setData({
        hasEmptyGrid: false,
        empytGrids: []
      });
    }
  },
  calculateDays(year, month) {
    let days = [];
    const thisMonthDays = this.getThisMonthDays(year, month);
    let mx_days = []
    for (let i = 1; i <= thisMonthDays; i++) {
      var old_day = {}
      old_day.mx_num= i;
      old_day.cs = '';
      days.push(i);
      mx_days.push(old_day);
    }
    //console.log(mx_days)
    this.setData({
      days,
      mx_days
    });
  },
  onLoad(options) {
    this.ph_set()
    const date = new Date();
    const cur_year = date.getFullYear();
    const cur_month = date.getMonth() + 1;
    const mx_day = date.getDate()
    const weeks_ch = ['日', '一', '二', '三', '四', '五', '六'];
    var week = date.getDay();
    // console.log(week)
    // console.log(weeks_ch[week]+'---'+mx_day)
    this.calculateEmptyGrids(cur_year, cur_month);
    this.calculateDays(cur_year, cur_month);
    this.getSystemInfo();
    var app = getApp()
    var that = this
    that.setData({
          cur_year,
          cur_month,
          mx_day,
          weeks_ch
    })
    app.util.getUserInfo(function(res){
        that.mx_ybj_config(res.memberInfo.id,cur_year,cur_month)
      //console.log(cur_year+'--'+cur_month+'--'+weeks_ch)
        that.setData({uid:res.memberInfo.id})
    })
  },
  /**
   * 设置开放月份
   */
  show_picker: function(e) {
    this.setData({
      month_hidden: false
    })
  },
  close_month_show:function(){
    this.setData({
      month_hidden: true
    })
  },
  /**
   * 偏好时间
   */
  show_week_picker: function(e) {
    this.setData({
      week_hidden: false
    })
  },
  close_week_show:function(){
    this.setData({
      week_hidden: true
    })
  },
  /**
   * 获取月份
   */
  monthChange:function(e){
    var month = e.detail.value
    //console.log(month)
    var show_title = ''
    if(month.length==0){
      this.setData({select_month_title:'请选择'})
    }else{
      for(var i = 0;i<month.length ;i++){
          show_title = show_title+' '+ this.data.mx_month[month[i]-1].title
      }
      this.setData({select_month_title:show_title,set_month:month})
    } 
  },
  /**
   * 获取偏好时间
   */
  weekChange:function(e){
    var weeks = e.detail.value
    var show_title = ''
    if(weeks.length==0){
      this.setData({select_week_title:'请选择'})
    }else{
      for(var i = 0;i<weeks.length ;i++){
          show_title = show_title+' '+ this.data.weekNum[weeks[i]-1].title
      }
      this.setData({select_week_title:show_title,set_week:weeks})
    } 
  },
  ph_set:function(cur_year,cur_month){
    cur_year = '2017'
    cur_month = '5'
    let days = [];
    const thisMonthDays = this.getThisMonthDays(cur_year,cur_month);
    let mx_days = []
    for (let i = 1; i <= thisMonthDays; i++) {
      var mx_weeks = this.get_weeks(cur_year+'-'+cur_month+'-'+i)
      if(mx_weeks=='周日'){
        console.log(cur_year+'-'+cur_month+'-'+i+'---'+mx_weeks)
      }
    }
   
  },
  mx_ybj_config(uid,cur_year,cur_month){
    var that = this
    var mx_month = this.data.mx_month
    var weekNum = this.data.weekNum
    var select_month_title = ''
    var select_week_title = ''
    data.get_ybj_config(uid,cur_year,cur_month,function(info){
        var ybj_config_month = info.ybj_config.cur_month
        //选中的月份
        for(var i in mx_month){
            if(ybj_config_month.indexOf(mx_month[i].id)==-1){
              mx_month[i].checked = ''
            }else{
              mx_month[i].checked = 'checked'
              select_month_title = select_month_title+' '+mx_month[i].title
            }
        }
        //选中的星期
        var ybj_config_week = []
        if(info.ybj_config.weeks!=false){
            ybj_config_week = info.ybj_config.weeks
        }
        // console.log(ybj_config_week)
        for(var i in weekNum){
            if(ybj_config_week.toString().indexOf(weekNum[i].id)==-1){
              weekNum[i].checked = ''
            }else{
              weekNum[i].checked = 'checked'
              select_week_title = select_week_title+' '+weekNum[i].title
            }
        }
        that.setData({mx_month:mx_month,select_month_title:select_month_title,weekNum:weekNum,select_week_title:select_week_title,set_month:info.ybj_config.cur_month,set_week:info.ybj_config.weeks})
        var new_arr = []
        if(info.data!=false){
            new_arr = JSON.parse(info.data)
        }
        var xxx_arr = info.mx_value
        for(var i in xxx_arr){
            for(var ii in xxx_arr[i]){

            }
        }
        arr = new_arr
        data_arr = info.mx_value
        var mx_days = that.data.mx_days
        var new_mx_days = []
        for(var i in mx_days){
            var num = mx_days[i].mx_num
            var mx_arr = {}
            mx_arr.mx_num = num
            if(new_arr.indexOf(num)!=-1){
                mx_arr.cs = 'mx_red'
            }else{
                mx_arr.cs = ''
            }
            new_mx_days.push(mx_arr)
        }
        that.setData({mx_days:new_mx_days,set_zhi:new_arr})
    })
  },
  get_weeks:function(weekByDate){
    var week = new Date(weekByDate).getDay();  
    //创建星期数组  
    var weekNum = this.data.weekNum
    // console.log(weekNum)
    return weekNum[week];
  },
  get_weeks_num:function(weekByDate){
    var week = new Date(weekByDate).getDay();  
    return week;
  },
  bindDateChange(e) {
    this.setData({
      date: e.detail.value,
      mr_date:''
    })
  },
  bindTimeChange: function(e) {
    this.setData({
      time: e.detail.value,
      mr_time: ''
    })
  },
  handleCalendar(e) {
    const handle = e.currentTarget.dataset.handle;
    const cur_year = this.data.cur_year;
    const cur_month = this.data.cur_month;
    var uid = this.data.uid
    if (handle === 'prev') {
      let newMonth = cur_month - 1;
      let newYear = cur_year;
      if (newMonth < 1) {
        newYear = cur_year - 1;
        newMonth = 12;
      }

      this.calculateDays(newYear, newMonth);
      this.calculateEmptyGrids(newYear, newMonth);
      this.mx_ybj_config(uid,newYear,newMonth)
      this.setData({
        cur_year: newYear,
        cur_month: newMonth
      })

    } else {
      let newMonth = cur_month + 1;
      let newYear = cur_year;
      if (newMonth > 12) {
        newYear = cur_year + 1;
        newMonth = 1;
      }

      this.calculateDays(newYear, newMonth);
      this.calculateEmptyGrids(newYear, newMonth);
      this.mx_ybj_config(uid,newYear,newMonth)
      this.setData({
        cur_year: newYear,
        cur_month: newMonth
      })
    }
  },
  get_day(e){
    if(arr.indexOf(e.currentTarget.dataset.id)==-1){
        arr.push(e.currentTarget.dataset.id)
    }else{
        var index = arr.indexOf(e.currentTarget.dataset.id)
        arr.splice(index,1)
    }
    var mx_days = this.data.mx_days
    var new_mx_days = []
    for(var i in mx_days){
        var num = mx_days[i].mx_num
        var mx_arr = {}
        mx_arr.mx_num = num
        if(arr.indexOf(num)!=-1){
            mx_arr.cs = 'mx_red'
        }else{
            mx_arr.cs = ''
        }
        new_mx_days.push(mx_arr)
    }
    this.setData({mx_days:new_mx_days,set_zhi:arr})
  },
  get_ms(e){
      this.setData({ms:e.detail.value})
  },
  add(){
    console.log(3333)
    var app = getApp()
    var that = this
    var cur_year = this.data.cur_year
    var cur_month = this.data.cur_month
    var uid = this.data.uid
    var set_value = this.data.set_zhi
    var set_month = this.data.set_month
    var set_week = this.data.set_week
    var ms = this.data.ms
    if(set_value.length==0){
        wx.showToast({
          title: '请选着样板间对外开放的时间',
          icon: 'success',
          duration: 2000
        })
        return false
    }
    var obj = {}
    obj.set_value = set_value
    obj.ms = ms
    obj.cur_year = cur_year
    obj.cur_month = cur_month
    obj.set_week = set_week
    obj.uid = uid
    obj.m = 'qcp_ddgj'
    app.util.request({
        url: 'entry//ybj_set',
        data: obj,
        cachetime: 30,
        success: function (res) {
        wx.showToast({
          title: '设置成功',
          icon: 'success',
          duration: 1000
        })
        setTimeout(function(){
           that.mx_ybj_config(uid,cur_year,cur_month)
        },2000)
        }
    })
  },
  onShareAppMessage() {
    return {
      title: '小程序日历',
      desc: '还是新鲜的日历哟',
      path: 'pages/index/index'
    }
  }
};

Page(conf);