// pages/user/ybj/index.js
var arr = []
var data = require('../../data/ybj_config.js')
var app = getApp()
const conf = {
  data: {
    hasEmptyGrid: false,
    mr_time:'点击选择>',
    mr_date:'点击选择>',
    winWidth: 0,  
    winHeight: 0,  
    // tab切换  
    currentTab: 1,  
    mx_arr:[],
    set_zhi:[],
    pic_path:app.pic_path,
    mx_dy:'none',
    ms:''
  },
  getSystemInfo() {
    try {
      const res = wx.getSystemInfoSync();
      this.setData({
        scrollViewHeight: res.windowHeight * res.pixelRatio || 667
      });
    } catch (e) {
      console.log(e);
    }
  },
  getThisMonthDays(year, month) {
    return new Date(year, month, 0).getDate();
  },
  getFirstDayOfWeek(year, month) {
    return new Date(Date.UTC(year, month - 1, 1)).getDay();
  },
  calculateEmptyGrids(year, month) {
    const firstDayOfWeek = this.getFirstDayOfWeek(year, month);
    let empytGrids = [];
    if (firstDayOfWeek > 0) {
      for (let i = 0; i < firstDayOfWeek; i++) {
        empytGrids.push(i);
      }
      this.setData({
        hasEmptyGrid: true,
        empytGrids
      });
    } else {
      this.setData({
        hasEmptyGrid: false,
        empytGrids: []
      });
    }
  },
  calculateDays(year, month) {
    let days = [];
    const thisMonthDays = this.getThisMonthDays(year, month);
    let mx_days = []
    for (let i = 1; i <= thisMonthDays; i++) {
      var old_day = {}
      old_day.mx_num= i;
      old_day.cs = '';
      days.push(i);
      mx_days.push(old_day);
    }
    //console.log(mx_days)
    this.setData({
      days,
      mx_days
    });
  },
  onLoad(options) {
    var user_type = options.user_type
    user_type=1
    const date = new Date();
    const cur_year = date.getFullYear();
    const cur_month = date.getMonth() + 1;
    const mx_day = date.getDate()
    const weeks_ch = ['日', '一', '二', '三', '四', '五', '六'];
    this.calculateEmptyGrids(cur_year, cur_month);
    this.calculateDays(cur_year, cur_month);
    this.getSystemInfo();
    var that = this
    that.setData({
          cur_year,
          cur_month,
          mx_day,
          weeks_ch,
          user_type:user_type
    })
    wx.getSystemInfo( {  
      success: function( res ) {  
        that.setData( {  
          winWidth: res.windowWidth,  
          winHeight: res.windowHeight  
        });  
      }  
    });
    app.util.getUserInfo(function(res){
      app.util.request({
            url: 'entry//check_is_sq_owner',
            data: {
                uid:res.memberInfo.id,
                m: 'qcp_ddgj',
            },
            cachetime: 30,
            success: function (info) {
                that.setData({is_sq:info.data.code})
            }
        })
        app.util.request({
            url: 'entry//xcx_yz_info',
            data: {
                uid:res.memberInfo.id,
                m: 'qcp_ddgj',
            },
            cachetime: 30,
            success: function (info) {
                that.setData({user_info:res.memberInfo,info:info.data.data})
            }
        })
        that.mx_ybj_config(res.memberInfo.id,cur_year,cur_month)
        data.get_wd_yuyue(res.memberInfo.id,function(info){
            that.setData({wd_yy_list:info.data,success_list:info.success_list})
        })
        that.setData({uid:res.memberInfo.id})
    })
  },
  mx_ybj_config(uid,cur_year,cur_month){
    var that = this
    data.get_ybj_config(uid,cur_year,cur_month,function(info){
        var new_arr = []
        if(info.data!=false){
            new_arr = JSON.parse(info.data)
        }
        arr = new_arr
        var mx_days = that.data.mx_days
        var new_mx_days = []
        for(var i in mx_days){
            var num = mx_days[i].mx_num
            var mx_arr = {}
            mx_arr.mx_num = num
            if(new_arr.indexOf(num)!=-1){
                mx_arr.cs = 'mx_red'
            }else{
                mx_arr.cs = ''
            }
            new_mx_days.push(mx_arr)
        }
        that.setData({mx_days:new_mx_days,set_zhi:new_arr,cg_num_arr:info.cg_num_arr})
    })
  },
  sq_yz:function(e){
    wx.navigateTo({
      url: '/pages/ybjyz/index'
    })
  },
  bindDateChange(e) {
    this.setData({
      date: e.detail.value,
      mr_date:''
    })
  },
  bindTimeChange: function(e) {
    this.setData({
      time: e.detail.value,
      mr_time: ''
    })
  },
  handleCalendar(e) {
    const handle = e.currentTarget.dataset.handle;
    const cur_year = this.data.cur_year;
    const cur_month = this.data.cur_month;
    var uid = this.data.uid
    var that = this
    if (handle === 'prev') {
      let newMonth = cur_month - 1;
      let newYear = cur_year;
      if (newMonth < 1) {
        newYear = cur_year - 1;
        newMonth = 12;
      }

      this.calculateDays(newYear, newMonth);
      this.calculateEmptyGrids(newYear, newMonth);
      that.mx_ybj_config(uid,newYear,newMonth)
      this.setData({
        cur_year: newYear,
        cur_month: newMonth
      })

    } else {
      let newMonth = cur_month + 1;
      let newYear = cur_year;
      if (newMonth > 12) {
        newYear = cur_year + 1;
        newMonth = 1;
      }

      this.calculateDays(newYear, newMonth);
      this.calculateEmptyGrids(newYear, newMonth);
      that.mx_ybj_config(uid,newYear,newMonth)
      this.setData({
        cur_year: newYear,
        cur_month: newMonth
      })
    }
  },
   /** 
     * 滑动切换tab 
     */  
  bindChange( e ) {  
    var that = this;  
    that.setData( { currentTab: e.detail.current });  
  },  
  /** 
   * 点击tab切换 
   */  
  swichNav( e ) {  
    var that = this;  
    if( this.data.currentTab === e.target.dataset.current ) {  
      return false;  
    } else {  
      that.setData( {  
        currentTab: e.target.dataset.current  
      })  
    }  
  },
  delete_yy(e){
    var id = e.currentTarget.dataset.id
    var uid = this.data.uid
    var that = this
    wx.showModal({
      title: '提示',
      content: '确定取消预约',
      success: function(res) {
        if (res.confirm) {
            app.util.request({
              url: 'entry//delete_wd_yy',
              data: {
                  id:id,
                  m: 'qcp_ddgj',
              },
              cachetime: 0,
              success: function (info) {
                  data.get_wd_yuyue(uid,function(info){
                    that.setData({wd_yy_list:info.data})
                })
              }
          })
        } else if (res.cancel) {
          
        }
      }
    })
    
  },
  go_pl:function(e){
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/pl/index?id='+id,
    })
  },
  mx_set_config(){
    wx.navigateTo({
      url: 'set',
    })
  },
  shou_yy(e){
    var cur_day = e.currentTarget.dataset.id
    var cur_year = this.data.cur_year
    var cur_month = this.data.cur_month
    var uid = this.data.uid
    var that = this
    app.util.request({
        url: 'entry//get_yy_wd',
        data: {
            uid:uid,
            cur_day:cur_day,
            cur_month:cur_month,
            cur_year:cur_year,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (info) {
            that.setData({yy_wd_list:info.data.data})
        }
    })
    this.setData({mx_dy:'show'})
  },
  close_ot(){
    this.setData({mx_dy:'none'})
  },
  onShareAppMessage() {
    return {
      title: '小程序日历',
      desc: '还是新鲜的日历哟',
      path: 'pages/index/index'
    }
  }
};

Page(conf);

