var app = getApp()
/**
 * 品牌团购列表 
 */
function get_pp_list(cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            op:'get_pp_list',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 品牌内页列表
 */
function get_list(pl,cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            pl:pl,
            op:'get_child_pp_list',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            typeof cb == "function" && cb(res.data);
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 拼团详情
 */
function get_brand_detail(id,uid,cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            id:id,
            uid,uid,
            op:'get_brand_detail',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 获得用户小区的样板间
 */
function get_user_ybj(xq_id,cb){
     app.util.request({
        url: 'entry//xcx_api',
        data: {
            xq_id:xq_id,
            op:'get_user_ybj',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 获取其他小区的样板间
 */
function get_other_ybj(xq_id,cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            xq_id:xq_id,
            op:'get_other_ybj',
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 检查用户是否已经团购过
 */
function check_ch_tg(id,uid,cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: {
            id:id,
            uid,uid,
            op:'check_ch_tg',
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('您已经参加过团购');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 生成订单
 */
function mx_add_order(obj,cb){
    app.util.request({
        url: 'entry//xcx_api',
        data: obj,
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 倒计时
 */
function show_time(time_end,cb){ 
     var time_start = new Date().getTime(); //设定当前时间
     if(time_start>=time_end){
        var mx_obj = {}
        mx_obj.int_day = '00'
        mx_obj.int_hour = '00'
        mx_obj.int_minute = '00'
        mx_obj.int_second = '00'
        mx_obj.end = 1
        typeof cb == "function" && cb(mx_obj);
     }else{
        //var time_end =  new Date("2017/02/05 00:00:00").getTime(); //设定目标时间
        //console.log(new Date("2017/02/05 00:00:00").getTime())
        // 计算时间差 
        var time_distance = time_end - time_start; 
        // 天
        var int_day = Math.floor(time_distance/86400000) 
        time_distance -= int_day * 86400000; 
        // 时
        var int_hour = Math.floor(time_distance/3600000) 
        time_distance -= int_hour * 3600000; 
        // 分
        var int_minute = Math.floor(time_distance/60000) 
        time_distance -= int_minute * 60000; 
        // 秒 
        var int_second = Math.floor(time_distance/1000) 
        // 时分秒为单数时、前面加零 
        if(int_day < 10){ 
            int_day = "0" + int_day; 
        } 
        if(int_hour < 10){ 
            int_hour = "0" + int_hour; 
        } 
        if(int_minute < 10){ 
            int_minute = "0" + int_minute; 
        } 
        if(int_second < 10){
            int_second = "0" + int_second; 
        } 
        var mx_obj = {}
        mx_obj.int_day = int_day
        mx_obj.int_hour = int_hour
        mx_obj.int_minute = int_minute
        mx_obj.int_second = int_second
        mx_obj.end = -1
        //console.log(int_day+'-'+int_hour+"-"+int_minute+"-"+int_second)
        typeof cb == "function" && cb(mx_obj);
        setTimeout(function(){
        // console.log(time_start)
            show_time(time_end,function(data){
                typeof cb == "function" && cb(data);
            })
        },1000);
     }
}

function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.redirectTo({
                    url: '/pages/index/index'
                })
            }
        }
    })
}

module.exports = {
    'get_pp_list':get_pp_list,
    'get_list':get_list,
    'get_brand_detail': get_brand_detail,
    'show_time':show_time,
    'get_user_ybj':get_user_ybj,
    'get_other_ybj':get_other_ybj,
    'check_ch_tg':check_ch_tg,
    'mx_add_order':mx_add_order,
    'failGo': failGo
};