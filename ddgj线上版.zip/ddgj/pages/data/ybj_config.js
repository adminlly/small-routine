var app = getApp()
/**
 * 拼团详情
 */
function get_ybj_config(uid,cur_year,cur_month,cb){
    app.util.request({
        url: 'entry//ybj_set_config',
        data: {
            uid:uid,
            cur_month:cur_month,
            cur_year:cur_year,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function get_user_phone(yz_uid,cb){
    app.util.request({
        url: 'entry//get_user_phone',
        data: {
            uid:yz_uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
/**
 * 获取我的预约
 */
function get_wd_yuyue(uid,cb){
    app.util.request({
        url: 'entry//get_wd_yuyue',
        data: {
            uid:uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                typeof cb == "function" && cb(res.data);
            } else {
                failGo('数据获取失败');
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
}
function failGo(content) {
    wx.showModal({
        content: content,
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.redirectTo({
                    url: '/pages/index/index'
                })
            }
        }
    })
}

module.exports = {
    'get_ybj_config': get_ybj_config,
    'get_user_phone':get_user_phone,
    'get_wd_yuyue':get_wd_yuyue,
    'failGo': failGo
};