var app = getApp()
Page({
  data:{
    hidden:true,
    show_hidden_title:'显示',
    hf_btn:'回复',
    ta_value:''
  },
  onLoad:function(options){
    // 生命周期函数--监听页面加载
    var that = this
    var id = options.id
    //id = 9
    app.util.getUserInfo(function (user) {
          var uid = user.memberInfo.id
          that.setData({id:id,uid:uid})
          that.get_list(id)
     });
   
  },
  get_list:function(id){
    var that = this
    app.util.request({
        url: 'entry//ybj_pl_list',
        data: {m:'qcp_ddgj',yid:id},
        cachetime: 0,
        success: function (res) {
            that.setData({list:res.data.data})
        }
    })
  },
  show_hidden:function(e){
      var id = e.currentTarget.dataset.id
      var list = this.data.list
      for(var i in list){
          console.log(list[i].parent_list.id)
          if(list[i].parent_list.id==id){
             if(list[i].parent_list.hidden){
               list[i].parent_list.hidden = false
              list[i].parent_list.hidden_title = '收起回复'
             }else{
               list[i].parent_list.hidden = true
              list[i].parent_list.hidden_title = '回复(222)'
             }
          }else{
              list[i].parent_list.hidden = true
              list[i].parent_list.hidden_title = '回复('+222+')'
          }
      }
      this.setData({list:list})
  },
  go_fb:function(){
    var id = this.data.id
    wx.navigateTo({
      url: 'fb?id='+id,
    })
  },
  formSubmit:function(e){
    var content = e.detail.value
    var list = this.data.list
    var that = this
    var obj = {}
    obj.yid = this.data.id
    obj.uid = this.data.uid
    obj.pid = content.pid
    obj.content = content.pl_content
    obj.m = 'qcp_ddgj'
    if(content.pl_content == ''){
      wx.showToast({
        title: '评论不能为空',
        icon: 'success',
        duration: 2000
      })
      return false
    }
    app.util.request({
      url: 'entry//ybj_pl',
      data: obj,
      cachetime: 0,
      success: function (res) {
          wx.showToast({
            title: '发布成功',
            icon: 'success',
            duration: 1000
          })
          setTimeout(function(){
            var data = res.data.data
            console.log(data)
            for(var i in list){
               if(list[i].parent_list.id==data.pid){
                  list[i].child_list.push(data)
               }
            }
            console.log(list)
            that.setData({list:list,ta_value:''})
          },1000)
      }
  })
  },
  onReady:function(){
    // 生命周期函数--监听页面初次渲染完成
    
  },
  onShow:function(){
    // 生命周期函数--监听页面显示
    this.get_list(this.data.id)
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
   
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
    
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
   
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
    
  }
})