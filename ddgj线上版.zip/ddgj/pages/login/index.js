// pages/login/index.js
var app = getApp()
Page({
  data:{
    mx_css:"",
    zhi:"none",
    html_view:[],
    xq_id:'',
    house_name:'',
    ts_msg:'请选择你所在的小区',
    uid:''
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var that = this
    app.util.getUserInfo(function(userInfo){
        that.setData({uid:userInfo.memberInfo.id,header:userInfo.memberInfo.header,nickname:userInfo.memberInfo.nickname})
    })
    
  },
  EventHandle:function(e){
    var that = this
    wx.getSystemInfo({
      success: function(res) {
        var mx_css = "width:"+res.windowWidth+"px;height:"+res.windowHeight+"px;"
        that.setData({
          mx_css:mx_css,
          zhi:"show"
        })
      }
    })
  },
  formSubmit:function(e){
      //console.log('form发生了submit事件，携带数据为：', e.detail.value)
      var data = e.detail.value
      var rst = true
      if(data.name==''){
        wx.showToast({
          title: '姓名不能为空',
          icon: 'success',
          duration: 2000
        })
        rst = false
      }
      if(data.phone==''){
          wx.showToast({
          title: '手机号码不能为空',
          icon: 'success',
          duration: 2000
        })
        rst = false
      }
      if(data.house_name==''){
          wx.showToast({
          title: '小区不能为空',
          icon: 'success',
          duration: 2000
        })
        rst = false
      }
      
      data.op='update_user'
      data.m = 'qcp_ddgj'
    
      if(rst){
          app.util.request({
          url: 'entry//xcx_api',
          data: data,
          cachetime: 30,
          success: function (res) {
            app.send_msg.send_msg(data.phone,'感谢登陆咚咚管家，看看邻居张小姐心中的好地板是什么样子，更多推荐尽在共享体验家居平台。',function(res){
              wx.showToast({
                title: '登录成功',
                icon: 'success',
                duration: 2000
              })
              setTimeout(function(){
                wx.navigateBack({
                  delta: 1, // 回退前 delta(默认为1) 页面
                })
              },2000)
            })
          }
      })
      }
  },
  close_show:function(){
    this.setData({
        zhi:"none"
     })
  },//选择小区
  s_xq:function(e){
    var zhi = e.currentTarget.id
    zhi =  zhi.split("-");
    var xq_id = zhi[0];
    var house_name = zhi[1];
    this.setData({
      xq_id:xq_id,house_name:house_name,zhi:'none',ts_msg:house_name
    })
  },
  select_info:function(e){
    var that = this
    if(e.detail.value!=''){
      app.util.request({
        url: 'entry//xcx_api',
        data: {
            op:'get_xq_info',
            mx_xq:e.detail.value,
            m: 'qcp_ddgj',
        },
        cachetime: 30,
        success: function (res) {
           that.setData({
            html_view:res.data.list
          })
        }
    })
    }
    
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})