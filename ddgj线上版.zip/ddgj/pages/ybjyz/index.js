// pages/ybjyz/index.js
var tcity = require("../data/city.js");
var app = getApp()
Page({
  data:{
    provinces: [],
    province: "",
    citys: [],
    city: "",
    countys: [],
    county: '',
    value: [9, 0, 0],
    values: [9, 0, 0],
    condition: false,
     mx_css:"",
    zhi:"none",
    pp_zhi:"none",
    html_view:[],
    brand_list:[],
    xq_id:'',
    house_name:'',
    uid:'',
    index:0,
    lp_msg:'请选择楼盘>',
    brand_msg:'请选择申请品牌>',
    hx_msg:'请选择住宅户型',
    hx_list:['一室','二室','三室','四室','五室','五室以上'],
    status:0,
    user_info:[]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
     console.log("onLoad");
    var that = this;
     app.util.getUserInfo(function (user) {
      //console.log(user)
        that.setData({user_info:user.memberInfo})
     })
    tcity.init(that);

    var cityData = that.data.cityData;


    const provinces = [];
    const citys = [];
    const countys = [];

    for(let i=0;i<cityData.length;i++){
      provinces.push(cityData[i].name);
    }
    //console.log('省份完成');
    for (let i = 0 ; i < cityData[0].sub.length; i++) {
      citys.push(cityData[9].sub[i].name)
    }
    //console.log('city完成');
    for (let i = 0 ; i < cityData[9].sub[0].sub.length; i++) {
      countys.push(cityData[9].sub[0].sub[i].name)
    }

    that.setData({
      'provinces': provinces,
      'citys':citys,
      'countys':countys,
      'province':cityData[9].name,
      'city':cityData[9].sub[0].name,
      'county':cityData[9].sub[0].sub[0].name
    })
    console.log('初始化完成');
  },
  bindChange: function(e) {
    //console.log(e);
    var val = e.detail.value
    var t = this.data.values;
    var cityData = this.data.cityData;
    
    if(val[0] != t[0]){
      //console.log('province no ');
      const citys = [];
      const countys = [];

      for (let i = 0 ; i < cityData[val[0]].sub.length; i++) {
        citys.push(cityData[val[0]].sub[i].name)
      }
      for (let i = 0 ; i < cityData[val[0]].sub[0].sub.length; i++) {
        countys.push(cityData[val[0]].sub[0].sub[i].name)
      }

      this.setData({
        province: this.data.provinces[val[0]],
        city: cityData[val[0]].sub[0].name,
        citys:citys,
        county: cityData[val[0]].sub[0].sub[0].name,
        countys:countys,
        values: val,
        value:[val[0],0,0]
      })
      
      return;
    }
    if(val[1] != t[1]){
      //console.log('city no');
      const countys = [];

      for (let i = 0 ; i < cityData[val[0]].sub[val[1]].sub.length; i++) {
        countys.push(cityData[val[0]].sub[val[1]].sub[i].name)
      }
      
      this.setData({
        city: this.data.citys[val[1]],
        county: cityData[val[0]].sub[val[1]].sub[0].name,
        countys:countys,
        values: val,
        value:[val[0],val[1],0]
      })
      return;
    }
    if(val[2] != t[2]){
      //console.log('county no');
      this.setData({
        county: this.data.countys[val[2]],
        values: val
      })
      return;
    }
    

  },
  open:function(){
    this.setData({
      condition:!this.data.condition
    })
  },
  EventHandle:function(e){
    var that = this
    var cs = e.currentTarget.id
    wx.getSystemInfo({
      success: function(res) {
        var mx_css = "width:"+res.windowWidth+"px;height:"+res.windowHeight+"px;"
        if(cs=='1'){
            that.setData({
              mx_css:mx_css,
              zhi:"show"
            })
        }else{
            that.setData({
              mx_css:mx_css,
              pp_zhi:"show"
            })
        }
      }
    })
  },
  close_show:function(e){
    var cs = e.currentTarget.id
    if(cs==1){
      this.setData({
        zhi:"none"
      })
    }else{
      this.setData({
        pp_zhi:"none"
     })
    }
  },//选择小区
  s_xq:function(e){
    var zhi = e.currentTarget.id
    zhi =  zhi.split("-");
    var xq_id = zhi[0];
    var house_name = zhi[1];
    this.setData({
      xq_id:xq_id,house_name:house_name,zhi:'none',lp_msg:house_name,province:zhi[2],city:zhi[3],county:zhi[4]
    })
  },
  select_info:function(e){
    var that = this
    if(e.detail.value!=''){
      app.util.request({
          url: 'entry//xcx_api',
          data: {
              mx_xq:e.detail.value,
              op:'get_xq_info',
              m: 'qcp_ddgj',
          },
          cachetime: 0,
          success: function (res) {
              that.setData({
                html_view:res.data.list
            })
          }
      })
    }
    
  },//选择品牌
  s_brand:function(e){
    var zhi = e.currentTarget.id
    zhi =  zhi.split("-");
    var b_id = zhi[0];
    var brand = zhi[1];
    this.setData({
      b_id:b_id,brand:brand,pp_zhi:'none',brand_msg:brand
    })
  },
  select_brand_info:function(e){
    var that = this
    if(e.detail.value!=''){
      app.util.request({
          url: 'entry//xcx_api',
          data: {
              mx_brand:e.detail.value,
              op:'get_brand_info',
              m: 'qcp_ddgj',
          },
          cachetime: 0,
          success: function (res) {
              that.setData({
                brand_list:res.data.list
            })
          }
      })
    }
    
  },
  bindPickerChange: function(e) {
    this.setData({
      index: e.detail.value,
    })
  },
  radioChange: function(e) {
    this.setData({status:e.detail.value})
  },
  formSubmit:function(e){
    var data = e.detail.value
    var status = this.data.status
    var xq_id = data.xq_id
    var brand = data.brand
    if(xq_id==''){
        wx.showToast({
        title: '请选择楼盘',
        icon: 'success',
        duration: 2000
      })
      return false
    }
    if(brand==''){
        wx.showToast({
        title: '请选择品牌',
        icon: 'success',
        duration: 2000
      })
      return false
    }
    if(status!=1){
      wx.showToast({
        title: '请先同意咚咚管家合作协议',
        icon: 'success',
        duration: 2000
      })
      return false
    }
    var obj = {}
    obj = data
    obj.uid = 2
    obj.m = 'qcp_ddgj'
    obj.uid = this.data.user_info.id
    var phone = this.data.user_info.phone
    app.util.request({
        url: 'entry//add_sq_yz',
        data: obj,
        cachetime: 0,
        success: function (res) {
          app.send_msg.send_msg(phone,'分享您心中的家居好货，享受购买优惠，邻居消费每单奖励百元现金红包。您的样板间申请已提交，客服将尽快与您联系，请保持电话畅通。',function(res){
            wx.showToast({
                title: '申请成功',
                icon: 'success',
                duration: 2000
              })
              setTimeout(function(){
                wx.navigateBack({
                  delta: 1, // 回退前 delta(默认为1) 页面
                })
              },2000)
          })
           
        }
    })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})