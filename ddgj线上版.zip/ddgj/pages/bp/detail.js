var WxParse = require('../../wxParse/wxParse.js');
var md5 = require('../../utils/md5.js');
var app = getApp()
Page({
  data:{
    jk_url:"https://3g.dongdonggj.com/app/index.php",
    img_url:"http://3g.dongdonggj.com/attachment/",
    mr_sc:'http://3g.dongdonggj.com/addons/qcp_ddgj/template/resources/new_tg/3.png',
    sp_info:[],
    see_num:'',
    pic_arr:[],
    bq:[],
    comment_num:'',
    mx_buy_num:'',
    share_title:"",
    share_desc:'',
    show_m:"none",
    'user_info':[],
    id:'',
    uid:''
  },
  onLoad:function(options){
    // 生命周期函数--监听页面加载
    //get_sp_detail
    //this.get_detail(options.id,1)
    var id = options.id
    //id = 5
    this.get_detail(id,1,app.globalData.uid)
    this.setData({id:id,uid:app.globalData.uid})
  },
  get_detail:function(id,pl,uid){
     console.log(app.globalData.uid)
    var that = this
    app.func.req('',{'op':'get_sp_detail','id':id,'pl':pl,'uid':uid},function(res){
      var mx_data = res
        WxParse.wxParse('content', 'html', mx_data.content, that,5);  
        that.setData({sp_info:mx_data.item,pic_arr:mx_data.pic_arr,bq:mx_data.bq,see_num:mx_data.see_num,comment_num:mx_data.comment_num,mx_buy_num:mx_data.mx_buy_num,share_title:mx_data.share_title,share_desc:mx_data.share_desc,user_info:mx_data.user_info,mr_sc:mx_data.sc_num})
    });
  },
  show_modal:function(){
    var that = this
    app.func.req('',{'op':'check_user','uid':that.data.uid},function(res){
         var code = res.code
         if(code==1){
            that.setData({show_m:"show"})
         }else{
           wx.showModal({
              title: '消息提示',
              content: '请先注册后后，方可参加团购',
              success: function(res) {
                if (res.confirm) {
                  wx.navigateTo({
                    url: '/pages/login/index'
                  })
                }
              }
            })
         }
    });
  },
  mxPay:function(){
    //console.log(this.data.id+'---'+this.data.uid)
    var title = this.data.sp_info.brand
    var fee = this.data.sp_info.dj_price
    var id = this.data.id
    var uid = this.data.uid
    var openid = app.globalData.openid
    var that = this
    app.wxpay.pay(title,fee,openid,function(res){
      if(res==1){
        that.add_order(id,uid,2,fee)
        wx.showToast({
          title: '支付成功',
          icon: 'success',
          duration: 2000
        })
      }else{
        that.add_order(id,uid,0,fee)
        wx.showToast({
          title: '支付失败,请前往个人中心支付订金',
          icon: 'success',
          duration: 2000
        })
      }
      
    })
  },
  add_order:function(id,uid,status,dj_price){
      app.func.req('',{'op':'add_sp_order','id':id,'uid':uid,'status':status,'dj_price':dj_price},function(res){
        console.log(res)
      })
  },
  close_modal:function(){
    this.setData({show_m:"none"})
  },
  go_home:function(){
      wx.switchTab({
        url: '/pages/index/index'
      })
  },
  my_sc:function(){
      // console.log(this.data.uid)
      var id = this.data.id
      var uid = this.data.uid
      var that = this
      app.func.req('',{'op':'sp_sc','uid':uid,'id':id},function(res){
        console.log(res.code)
          if(res.code==1){
              that.setData({
                mr_sc:"http://3g.dongdonggj.com/addons/qcp_ddgj/template/resources/new_tg/q3.png"
              })
          }else{
              that.setData({
                mr_sc:"http://3g.dongdonggj.com/addons/qcp_ddgj/template/resources/new_tg/3.png"
              })
          }
      })
  },
  onReady:function(){
    // 生命周期函数--监听页面初次渲染完成
    
  },
  onShow:function(){
    // 生命周期函数--监听页面显示
    
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
    
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
    
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
    
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
    
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
    var id = this.data.id
    return {
      title: this.data.share_title, // 分享标题
      desc: this.data.share_desc, // 分享描述
      path: 'pages/bp/detail?id='+id // 分享路径
    }
  }
})