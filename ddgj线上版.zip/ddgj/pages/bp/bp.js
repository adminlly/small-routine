var app = getApp()
Page({
  data:{
    list:[],
    resource_name:'',
    img_url:"http://3g.dongdonggj.com/attachment/",
    brand_type:[],
    index:0,
    rce:'',
    resource:''
  },
  onLoad:function(options){
    // 生命周期函数--监听页面加载
    var that = this
    var pl = ''
    if(options.pl!=undefined){
        pl=options.pl
    }
    var resource = ''
    try {
        var value = wx.getStorageSync('resource')
        if (value) {
            // Do something with return value
            resource = value
        }
      } catch (e) {
        // Do something when catch error
    }
    that.get_list(pl,resource)
    that.setData({rce:resource})
  },
  get_list:function(pl,resource){
    var that = this
    app.func.req('',{'op':'get_bp_list','pl':pl,'resource':resource},function(res){
      var brand_type = res.brand_type;
        wx.setNavigationBarTitle({
          title: res.resource_name
        })
        that.setData({list:res.list,brand_type:brand_type})
    });
  },
  bindPickerChange: function(e) {
    // console.log(e)
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.get_list(e.detail.value,this.data.rce);
    this.setData({
      index: e.detail.value
    })
  },
  onReady:function(){
    // 生命周期函数--监听页面初次渲染完成
  },
  onShow:function(){
    // 生命周期函数--监听页面显示
    var that = this
    var pl = '';
    var resource = ''
    try {
        var value = wx.getStorageSync('resource')
        if (value) {
            // Do something with return value
            resource = value
        }
      } catch (e) {
        // Do something when catch error
    }
    that.get_list(pl,resource)
    that.setData({rce:resource})
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
   
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
    
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
   
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
    
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
    return {
      title: '爆品详情', // 分享标题
      desc: '欢迎来到咚咚小管家，爆品购买页面', // 分享描述
      path: 'pages/bp/bp' // 分享路径
    }
  }
})