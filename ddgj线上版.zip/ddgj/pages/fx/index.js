// pages/fx/index.js
var app = getApp()
var data = require('../data/fx.js')
var ybj = require('../data/ybj.js')
Page({
  data:{
    sn:'none',
    cs_id:1,
    mr_px:'checked',
    ot_px:'',
    pic_path:app.pic_path,
    data_list:[],
    winWidth: 0,  
    winHeight: 0,
    list:{},
    d_list:{},
    items:[],
    px_value:'筛选',
    top_btn:1,
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
     var that = this
    /** 
     * 获取系统信息 
     */  
    wx.getSystemInfo( {  
      success: function( res ) {  
        that.setData( {  
          winWidth: res.windowWidth,  
          winHeight: res.windowHeight  
        });  
      }  
    });
    data.xcx_fx_brand_pid('',1,function(res){
      that.setData({list:res.data,d_list:res.data})
    }) 
    ybj.get_brand_type(function(res){
        that.setData({items:res.list})
    })
  },
  mr:function(){
    var d_list = this.data.d_list
     this.setData({mr_px:'checked',ot_px:'',list:d_list,px_value:'筛选'})
  },
  checkboxChange: function(e) {
    //console.log('checkbox发生change事件，携带value值为：', e.detail.value)
    var value = e.detail.value
    var ybj_data = this.data.d_list
    var new_tbj = []
    var px_value = ''
    for(var ii in ybj_data){
        var px_id = ybj_data[ii].pl.id
        for(var i=0;i<value.length;i++)
        {
            if(value[i]!=-1){
                if(px_id==value[i]){
                  px_value = px_value+ybj_data[ii].pl.title+';'
                  new_tbj.push(ybj_data[ii])
                }
            }
        }
    }
    this.setData({list:new_tbj,px_value:'筛选'})
    var len = value.length
    if(len==0){
        this.setData({mr_px:'checked',list:ybj_data,px_value:'筛选'})
    }else if(len==1){
        if(value.toString().indexOf('-1')>-1){
              this.setData({mr_px:''})
        }
    }else{
        if(value.toString().indexOf('-1')>-1){
              this.setData({mr_px:''})
        }
    }
  },
  show_px:function(e){
      var dj_id = e.currentTarget.dataset.id
      var cs_id = this.data.cs_id 
      if(dj_id==cs_id){
          this.setData({sn:'show',cs_id:2,top_btn:2})
      }else{
          this.setData({sn:'none',cs_id:1,top_btn:1})
      }
  },
  close_px:function(e){
      this.setData({sn:'none',cs_id:1,top_btn:1})
  },
  go_more:function(e){
    var id = e.currentTarget.dataset.id
      wx.navigateTo({
        url: 'more?id='+id,
      })
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
    return {
      title: '全品类家装品牌，下单即有返现', // 分享标题
      desc: '是不是心动了，那就赶紧的行动起来，错过了就真的错过了', // 分享描述
      path: '/pages/fx/index' // 分享路径
    }
  }
})