// pages/fx/detail.js
var app = getApp()
var data = require('../data/fx.js')
Page({
  data:{
    brand_info:[],
    user_info:[],
    pic_path:app.pic_path,
    ybj_list1:[],
    ybj_list2:[],
    id:'',
    mr_sc:'../resources/sc1.png'
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    var id = options.id
    var that = this
    app.util.getUserInfo(function(res){
        data.get_brand_info(id,res.memberInfo.id,function(info){
          that.setData({brand_info:info.data,user_info:res.memberInfo,id:id,mr_sc:info.data.mr_sc})
        })
        that.get_user_xq_ybj(res.memberInfo.xq_id)
    })
  },
  /**
   * 获取我所在小区的样板间情况
   */
  get_user_xq_ybj:function(xq_id){
    var that = this
    wx.getLocation({
      type: 'wgs84',
      success: function(res) {
        var lat = res.latitude
        var lng = res.longitude
        app.util.request({
          url: 'entry//xcx_user_xq_ybj',
          data: {
              xq_id:xq_id,
              lat:lat,
              lng:lng,
              m: 'qcp_ddgj',
          },
          cachetime: 0,
          success: function (res) {
            console.log(res.data.ybj_list1)
              that.setData({ybj_list1:res.data.ybj_list1,ybj_list2:res.data.ybj_list2})
          }
        })
    }
    })
  },
  /**
   * 跳转到主页
   */
  go_home:function(){
      wx.switchTab({
        url: '/pages/index/index',
      })
  },
  /**
   * 跳转到个人中心
   */
  go_user:function(){
      wx.switchTab({
        url: '/pages/user/index',
      })
  },
  go_ybj_list:function(e){
    wx.switchTab({
        url: '/pages/ybj/index',
      })
  },
  /**
   * 收藏
   */
  my_sc:function(){
      // console.log(this.data.uid)
  },
  go_sq:function(){
    wx.navigateTo({
      url: '/pages/ybjyz/index',
    })
  },
  /**
   * 收藏
   */
  my_sc:function(){
      var that = this
      var id = that.data.id
      var uid = that.data.user_info.id
      console.log(id+'--'+uid)
      app.util.request({
        url: 'entry//fx_sc',
        data: {
            id:id,
            uid,uid,
            m: 'qcp_ddgj',
        },
        cachetime: 0,
        success: function (res) {
            if (res.data.code == 1) {
                that.setData({mr_sc:"../resources/sc2.jpg"})
            } else {
                that.setData({mr_sc:"../resources/sc1.png"})
            }
        },
        fail: function () {
            failGo('请检查连接地址');
        }
    })
  },
  /**
   * 跳转到支付页面
   */
  go_pay:function(){
    var user_info = this.data.user_info
    if(user_info.name=='' || user_info.name == null){
           app.register()
    }else{
      var id = this.data.id
      wx.navigateTo({
        url: '/pages/pay/pay?id='+id,
      })
    }
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})