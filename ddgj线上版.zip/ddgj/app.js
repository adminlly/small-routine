//app.js
var https = require('utils/https.js') 
var mx_pay = require('utils/pay.js')
var send_msg =  require('utils/send_message.js')
App({
	onLaunch: function () {
		//程序启到时，直接跳转到应用模块中
		var that = this
	},
	onShow: function () {
	},
	onHide: function () {
	},
	onError: function (msg) {
		console.log(msg)
	},
	//加载微擎工具类
	util: require('utils/util.js'),
	//用户信息，sessionid是用户是否登录的凭证
	getUserInfo:function(cb){
		var that = this
		if(this.globalData.userInfo){
			typeof cb == "function" && cb(this.globalData.userInfo)
		}else{
			 //调用登录接口
			wx.login({
				success: function (e) {
				var code = e.code
				if (code) {
					wx.getUserInfo({
					success: function (res) {
						var user_info = res.userInfo
						var nickName = user_info.nickName
						var gender = user_info.gender
						var header = user_info.avatarUrl
						var obj = {}
						obj.nickname = nickName
						obj.code = code
						obj.gender = gender
						obj.header = header
						obj.op = 'get_user_id'
						obj.m = 'qcp_ddgj'
						obj.sq = 1
						that.add_user(obj, function (user) {
							// console.log(user)
							that.globalData.userInfo = user
							typeof cb == "function" && cb(that.globalData.userInfo)
						})
					},
					fail: function () {
						var obj = {}
						obj.code = code
						obj.op = 'get_user_id'
						obj.m = 'qcp_ddgj'
						obj.sq = -1
						that.add_user(obj, function (user) {
							that.globalData.userInfo = user
							typeof cb == "function" && cb(that.globalData.userInfo)
						})
						console.log('获取用户信息失败')
					}
					})
				} else {
					console.log('获取用户登录态失败！' + r.errMsg)
				}

				}
			})
		}
	},
	add_user: function (obj, cb) {
		https.req('',obj,function(res){
			typeof cb == "function" && cb(res);
		});
	},
	globalData: {
		uid: '',
		userInfo: null
	},
	register:function(){
		wx.showModal({
        content: '请先注册',
        showCancel: false,
        success: function (res) {
            if (res.confirm) {
                wx.navigateTo({
                    url: '/pages/login/index'
                })
            }
        }
    	})
	},
	func:{  
		req:https.req
	},
	wxpay:{
		pay:mx_pay.pay
	},
	wx_user_pay:{
		pay_to_user:mx_pay.pay_to_user
	},
	userInfo: {
		sessionid: null,
	},
	send_msg:{
		send_msg:send_msg.send_message
	},
	pic_path:'https://xcx.dongdonggj.com/attachment/',
	//站点信息
	siteInfo: {
		'uniacid': '2', //公众号uniacid
		'acid': '2', 
		'multiid': '0.6',  //小程序版本id
		'version': '1.0.0',  //小程序版本
		'siteroot': 'https://xcx.dongdonggj.com/app/index.php',  //站点URL
		'token': "hA0U7d0Wd4Ehhh0a8DWJYAUh4GbDYZg0" //将用于接口中的数据安全校验
	}
});